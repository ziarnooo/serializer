# CLAUDE.md

Plik dla Claude Code — szybka orientacja w projekcie. Czytaj ten plik jako pierwszy.

## Czym jest ten projekt

Chrome extension (Manifest V3) do nagrywania i odtwarzania szablonów wypełniania formularzy. Działa **w pełni lokalnie** — zero komunikacji sieciowej, dane w `chrome.storage.local` / `chrome.storage.session`. Główny use case: dokumentacja medyczna (lekarz nagrywa szablon dla powtarzalnych pól wizyty, potem 1 klik = wypełnione pola do akceptacji).

**Stan obecny:** v0.2 — multi-page recording + playback z pauzami przed nawigacją. Wcześniejsza v0.1 robiła tylko jedną stronę.

## Pliki w repo

```
manifest.json          — MV3 manifest (permissions, content scripts, side panel)
background.js          — service worker: badge, webNavigation, session resume
content.js             — wstrzykiwany na każdej stronie: hover/click, fill/click playback,
                         signature building, field matching, wait_for_stable_dom
content.css            — style podświetleń (hover/pending/recorded/filled/click)
sidepanel.html/css/js  — UI (Side Panel API): home, recording, save, playback views
icons/                 — 16/48/128 px PNG ikony

docs/                  — pełna dokumentacja (zacznij od ARCHITECTURE.md)
test-form.html         — formularz jednostronicowy (legacy, do testów v0.1)
test-form-multi/       — formularz 3-stronicowy z pełnym przeładowaniem URL
                         (worst case dla wtyczki = opcja A)
```

## Najważniejsze pojęcia

- **Signature** — multi-warstwowy "odcisk palca" pola (id, name, label, position, stable CSS path). Zapisywany przy nagrywaniu, używany przy odtwarzaniu do znalezienia pola. Patrz `docs/FIELD_MATCHING.md`.
- **Step** — atom szablonu, dwa typy: `fill` (wypełnij pole) i `click` (kliknij przycisk, zwykle nawigacyjny). Patrz `docs/DATA_MODEL.md`.
- **Recording session** — stan w `chrome.storage.session` żyjący między reloadami stron. Wskrzeszany przez background.js + sidepanel.js przy nawigacji. Patrz `docs/MULTI_PAGE.md`.
- **Playback session** — analogicznie, ale dla odtwarzania. Sterowany z sidepanel.js, krok po kroku, z pauzą-i-potwierdzeniem przed każdym `click`.

## Kluczowe decyzje projektowe (NIE zmieniać bez przedyskutowania)

1. **Wtyczka NIE klika "Zapisz" formularza.** Ostatnim krokiem szablonu zawsze jest `fill`, lekarz świadomie zatwierdza wizytę ręcznie. To jest decyzja bezpieczeństwa medycznego — wtyczka pomaga, ale nie podejmuje finalnej akcji.
2. **Każde przejście na nową stronę wymaga potwierdzenia.** "Pauza-i-potwierdź" przed każdym `click` step. Lekarz widzi co się stanie i akceptuje.
3. **Zero sieci.** CSP `connect-src 'self'`, brak telemetrii, brak analytics, brak error reportingu. RODO + tajemnica lekarska.
4. **Zero LLM.** Świadomie odrzucone — patrz `docs/ROADMAP.md` § "Co odrzucone".
5. **Pola podświetlane na żółto po wypełnieniu.** Lekarz widzi, że to wtyczka wpisała wartość, weryfikuje, koryguje jeśli trzeba.
6. **Brak dostępu do `host_permissions` poza `<all_urls>`** — `<all_urls>` jest potrzebne tylko żeby content script się wstrzyknął na dowolny EDM. Wtyczka nie robi cross-domain żądań.

## Konwencje kodu

- **Vanilla JS, brak frameworków.** Mała paczka, łatwa do audytu (ważne w kontekście medycznym — ktoś może chcieć zweryfikować że wtyczka nie wycieka danych).
- **Komentarze po polsku.** User jest Polakiem, target audience też. Nazwy zmiennych i funkcji po angielsku (konwencja JS).
- **CSS prefiksowany `.ftf-`** w content.css żeby nie kolidować ze stronami EDM.
- **`!important` we wszystkich stylach content scriptu** — bo strony EDM mogą mieć agresywne CSS reset.
- **Brak buildu.** Edytuj pliki bezpośrednio, przeładuj wtyczkę w `chrome://extensions`.

## Jak testować zmiany

1. Otwórz `chrome://extensions`
2. Włącz **Tryb dewelopera**
3. **Załaduj rozpakowane** → wskaż folder repo (już istnieje pewnie)
4. Po zmianach kodu — kliknij **przeładuj** (ikona kółka) na karcie wtyczki w `chrome://extensions`
5. Otwórz `test-form-multi/page1.html` w nowej karcie
6. Pełny smoke test: nagraj 3-stronicowy szablon, zapisz, odśwież stronę 1, odtwórz
7. Sprawdź `chrome://extensions` → "Errors" w karcie wtyczki — tam są niewyłapane wyjątki z service workera
8. Dla content scriptu: DevTools → Console (zwykła zakładka strony)
9. Dla sidepanela: PPM na panelu → Inspect → osobna instancja DevTools

## Częste pułapki

- **Side panel nie odświeża się po przeładowaniu wtyczki.** Zamknij panel i otwórz ponownie kliknięciem ikony.
- **Content script może nie istnieć na chrome://** stronach. Wszystkie wywołania `sendToContent` zwracają `null` jeśli brak content scriptu — kod sidepanel.js to obsługuje.
- **`chrome.storage.session` znika po zamknięciu okna Chrome.** To jest celowe — nie chcemy pozostawić sesji nagrywania na zawsze. Persystowane szablony są w `chrome.storage.local`.
- **`webNavigation.onCompleted`** może się odpalić zanim content script się zainicjalizuje. Stąd `setTimeout(200)` w background.js przed wysłaniem `SESSION_RESUME`.

## Co dalej (priorytet)

Patrz `docs/ROADMAP.md`. Top 3:
1. Edycja istniejącego szablonu bez nagrywania od zera
2. Eksport/import JSON (do dzielenia szablonów między lekarzami)
3. Walidacja wartości (np. tętno musi być w zakresie 30-200, ostrzeżenie jeśli nie)

## Kontakt

Właściciel: Dominik (MasterBorn). Use case: lekarze wypełniający dokumentację medyczną. Język UI: polski. Konwersacje z LLM podczas budowy: prowadzone w mieszance pl/en.
