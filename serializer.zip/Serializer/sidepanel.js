// ============================================
// Serializer - Side Panel logic (v0.2)
// ============================================
//
// Architektura stanów:
//
// 1) RECORDING — stan trzymany w chrome.storage.session pod kluczem 'session_recording':
//    {
//      tabId, kind: 'recording', activeMode: 'fields' | 'nav' | null,
//      startedAt, firstPageUrl, currentPageUrl,
//      steps: [ { type: 'fill' | 'click', ... } ]
//    }
//    Persystowany żeby przeżyć przeładowanie strony (opcja A — full reload).
//    Po reload: background → content script SESSION_RESUME → wznawia recording-fields.
//    Sidepanel czyta sesję przy starcie i odbudowuje UI.
//
// 2) PLAYBACK — stan trzymany w 'session_playback':
//    {
//      tabId, kind: 'playback', templateId,
//      stepIndex, paused, awaitingNavConfirm,
//      log: [ { ok, label, value?, reason? } ]
//    }
//    Sidepanel sterownikiem — wykonuje kroki sekwencyjnie, między stronami
//    przetrwa dzięki sesji (po reload odczytuje stan i kontynuuje).

const SESSION_KEYS = {
  RECORDING: 'session_recording',
  PLAYBACK: 'session_playback'
};

// ============ STATE (pamięć runtime, źródłem prawdy jest sesja) ============

const state = {
  view: 'home',
  currentTab: null,
  currentUrl: null,
  matchingTemplates: [],
  // Buforowany aktualny stan sesji (synchronizowany przy każdej zmianie)
  recordingSession: null,
  playbackSession: null,
  // Pole właśnie wybrane, czeka na zatwierdzenie w edytorze
  pendingField: null,
  // Indeks steps[] kroku click czekającego na nadanie nazwy (po nawigacji)
  pendingNavRename: null
};

// ============ INIT ============

document.addEventListener('DOMContentLoaded', async () => {
  bindEvents();
  await refreshActiveTab();
  await restoreFromSession();

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'FIELD_SELECTED') {
      onFieldSelected(msg);
    } else if (msg.type === 'NAV_ELEMENT_SELECTED') {
      onNavSelected(msg);
    } else if (msg.type === 'RECORDING_CANCELLED') {
      // ESC w content scripcie - zostawiamy sesję, ale wyłączamy aktywny tryb
      if (state.recordingSession) {
        state.recordingSession.activeMode = null;
        saveRecordingSession();
      }
    } else if (msg.type === 'NAVIGATION_OCCURRED') {
      // Strona się przeładowała / SPA navigation
      onNavigationOccurred(msg);
    }
  });

  chrome.tabs.onActivated.addListener(refreshActiveTab);
  chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
    if (changeInfo.status === 'complete') refreshActiveTab();
  });
});

// ============ EVENT BINDINGS ============

function bindEvents() {
  // HOME
  document.getElementById('btn-start-recording').addEventListener('click', startNewRecording);
  document.getElementById('btn-apply-template').addEventListener('click', applyMatchingTemplate);

  // RECORDING
  document.getElementById('btn-cancel-recording').addEventListener('click', cancelRecording);
  document.getElementById('btn-finish-recording').addEventListener('click', finishRecording);
  document.getElementById('btn-add-nav-step').addEventListener('click', startRecordingNavClick);

  // FIELD EDITOR
  document.getElementById('btn-save-field').addEventListener('click', savePendingField);
  document.getElementById('btn-cancel-field').addEventListener('click', cancelPendingField);

  // NAV EDITOR
  document.getElementById('btn-save-nav').addEventListener('click', savePendingNav);
  document.getElementById('btn-cancel-nav').addEventListener('click', cancelPendingNav);

  // SAVE
  document.getElementById('btn-back-to-recording').addEventListener('click', () => switchView('recording'));
  document.getElementById('btn-save-template').addEventListener('click', saveTemplate);

  // PLAYBACK
  document.getElementById('btn-pb-confirm-nav').addEventListener('click', confirmNavAndContinue);
  document.getElementById('btn-pb-pause').addEventListener('click', pausePlayback);
  document.getElementById('btn-pb-resume').addEventListener('click', resumePlayback);
  document.getElementById('btn-pb-stop').addEventListener('click', stopPlayback);
  document.getElementById('btn-pb-done').addEventListener('click', finishPlayback);
}

// ============ TAB / URL ============

async function refreshActiveTab() {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      const tab = tabs[0];
      if (!tab) return resolve();
      state.currentTab = tab.id;
      state.currentUrl = tab.url;
      document.getElementById('page-url').textContent = tab.url || '—';
      document.getElementById('rec-page-url').textContent = tab.url || '—';
      await refreshTemplatesUI();
      resolve();
    });
  });
}

async function refreshTemplatesUI() {
  const { templates = [] } = await chrome.storage.local.get('templates');

  const matching = templates.filter(t => urlMatches(state.currentUrl, t.matchUrl));
  state.matchingTemplates = matching;

  const card = document.getElementById('matching-template-card');
  if (matching.length > 0) {
    card.style.display = 'block';
    document.getElementById('matching-template-name').textContent = matching[0].name;
    document.getElementById('matching-template-meta').textContent =
      summarizeTemplate(matching[0]) +
      (matching.length > 1 ? ` • +${matching.length - 1} innych` : '');
  } else {
    card.style.display = 'none';
  }

  const listEl = document.getElementById('templates-list');
  if (templates.length === 0) {
    listEl.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">○</div>
        <p>Brak zapisanych szablonów</p>
        <p class="empty-hint">Naciśnij "Nagraj nowy szablon" żeby zacząć.</p>
      </div>`;
    return;
  }

  listEl.innerHTML = templates.map((t, idx) => `
    <div class="template-row" data-idx="${idx}">
      <div class="template-row-info">
        <div class="template-row-name">${escapeHtml(t.name)}</div>
        <div class="template-row-meta">${summarizeTemplate(t)} · ${escapeHtml(t.matchUrl || 'dowolna strona')}</div>
      </div>
      <div class="template-row-actions">
        <button class="icon-btn" data-action="apply" data-idx="${idx}" title="Zastosuj">▶</button>
        <button class="icon-btn danger" data-action="delete" data-idx="${idx}" title="Usuń">✕</button>
      </div>
    </div>
  `).join('');

  listEl.querySelectorAll('[data-action]').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const idx = parseInt(btn.dataset.idx, 10);
      const action = btn.dataset.action;
      if (action === 'apply') {
        await applyTemplate(templates[idx]);
      } else if (action === 'delete') {
        if (confirm(`Usunąć szablon "${templates[idx].name}"?`)) {
          templates.splice(idx, 1);
          await chrome.storage.local.set({ templates });
          await refreshTemplatesUI();
          chrome.runtime.sendMessage({ type: 'REFRESH_BADGE' });
        }
      }
    });
  });
}

function summarizeTemplate(t) {
  const fills = t.steps.filter(s => s.type === 'fill').length;
  const clicks = t.steps.filter(s => s.type === 'click').length;
  const pages = clicks + 1;
  return `${fills} pól · ${pages} stron${pages === 1 ? 'a' : (pages < 5 ? 'y' : '')}`;
}

function urlMatches(url, pattern) {
  if (!pattern || !url) return false;
  try {
    const regex = new RegExp('^' + pattern.replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*') + '$');
    return regex.test(url);
  } catch {
    return url === pattern;
  }
}

// ============ VIEW SWITCHING ============

function switchView(name) {
  state.view = name;
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  const target = document.getElementById('view-' + name);
  if (target) target.classList.add('active');
}

// ============ SESSION HELPERS ============

async function loadSession(key) {
  const data = await chrome.storage.session.get(key);
  return data[key] || null;
}

async function saveRecordingSession() {
  if (state.recordingSession) {
    await chrome.storage.session.set({ [SESSION_KEYS.RECORDING]: state.recordingSession });
  } else {
    await chrome.storage.session.remove(SESSION_KEYS.RECORDING);
  }
}

async function savePlaybackSession() {
  if (state.playbackSession) {
    await chrome.storage.session.set({ [SESSION_KEYS.PLAYBACK]: state.playbackSession });
  } else {
    await chrome.storage.session.remove(SESSION_KEYS.PLAYBACK);
  }
}

async function restoreFromSession() {
  state.recordingSession = await loadSession(SESSION_KEYS.RECORDING);
  state.playbackSession = await loadSession(SESSION_KEYS.PLAYBACK);

  if (state.recordingSession) {
    switchView('recording');

    // Sprawdź czy panel był zamknięty gdy user kliknął przycisk nawigacyjny
    const stored = await chrome.storage.session.get('pending_nav_click');
    const pendingNavClick = stored.pending_nav_click;

    if (pendingNavClick && pendingNavClick.pageUrl !== state.currentUrl) {
      // Nawigacja odbyła się gdy panel był zamknięty — dopisz click step teraz
      const defaultLabel = pendingNavClick.meta?.label || 'Przejdź dalej';
      state.recordingSession.steps.push({
        type: 'click',
        pageUrl: pendingNavClick.pageUrl,
        signature: pendingNavClick.signature,
        label: defaultLabel,
        waitForNavigation: true
      });
      state.pendingNavRename = state.recordingSession.steps.length - 1;
      state.recordingSession.currentPageUrl = state.currentUrl;
      state.recordingSession.activeMode = 'fields';
      await chrome.storage.session.remove('pending_nav_click');
      await saveRecordingSession();
    } else if (pendingNavClick) {
      // Ten sam URL — stary pending_nav_click (np. nawigacja nie doszła do skutku), wyczyść
      await chrome.storage.session.remove('pending_nav_click');
    }

    renderRecordedSteps();
    document.getElementById('rec-page-url').textContent = state.currentUrl || '—';

    if (state.pendingNavRename !== null) {
      const step = state.recordingSession.steps[state.pendingNavRename];
      showNavEditor({ label: step?.label || 'Przejdź dalej' });
      document.getElementById('rec-sub-text').textContent =
        'Nowa strona — nadaj nazwę przejściu i klikaj kolejne pola.';
    } else {
      document.getElementById('rec-sub-text').textContent =
        'Kontynuujesz nagrywanie. Klikaj kolejne pola lub dodaj przejście dalej.';
    }

    if (state.recordingSession.activeMode === 'fields') {
      sendToContent({ type: 'START_RECORDING_FIELDS' });
    }
    document.getElementById('btn-finish-recording').disabled =
      (state.recordingSession.steps.filter(s => s.type === 'fill').length === 0);
  } else if (state.playbackSession) {
    // Wznów widok playback i kontynuuj od następnego kroku
    switchView('playback');
    renderPlaybackUI();
    // Po reload kontynuujemy
    setTimeout(() => continuePlayback(), 500);
  }
}

// ============ RECORDING FLOW ============

async function startNewRecording() {
  // Wyczyść poprzednią sesję
  await chrome.storage.session.remove(SESSION_KEYS.RECORDING);

  state.recordingSession = {
    tabId: state.currentTab,
    kind: 'recording',
    activeMode: 'fields',
    startedAt: new Date().toISOString(),
    firstPageUrl: state.currentUrl,
    currentPageUrl: state.currentUrl,
    steps: []
  };
  state.pendingField = null;
  state.pendingNavRename = null;

  await saveRecordingSession();

  switchView('recording');
  renderRecordedSteps();
  hideFieldEditor();
  hideNavEditor();
  document.getElementById('rec-sub-text').textContent = 'Wróć do strony i klikaj pola.';
  document.getElementById('btn-finish-recording').disabled = true;

  await sendToContent({ type: 'CLEAR_RECORDED_MARKS' });
  await sendToContent({ type: 'START_RECORDING_FIELDS' });
}

async function startRecordingNavClick() {
  if (!state.recordingSession) return;
  if (state.recordingSession.steps.filter(s => s.type === 'fill').length === 0) {
    if (!confirm('Nie nagrałeś jeszcze żadnego pola na tej stronie. Naprawdę dodać przejście dalej teraz?')) return;
  }
  state.recordingSession.activeMode = 'nav';
  await saveRecordingSession();
  await sendToContent({ type: 'START_RECORDING_NAV_CLICK' });
}

async function cancelRecording() {
  if (state.recordingSession && state.recordingSession.steps.length > 0) {
    if (!confirm('Anulować nagrywanie? Wszystkie nagrane kroki zostaną utracone.')) return;
  }
  await sendToContent({ type: 'STOP_RECORDING' });
  await sendToContent({ type: 'CLEAR_RECORDED_MARKS' });
  state.recordingSession = null;
  state.pendingField = null;
  state.pendingNavRename = null;
  await saveRecordingSession();
  switchView('home');
}

// === FIELD EDITOR ===

function onFieldSelected(msg) {
  state.pendingField = { signature: msg.signature, meta: msg.meta };
  showFieldEditor(msg.meta);
}

function showFieldEditor(meta) {
  hideNavEditor();
  const editor = document.getElementById('field-editor');
  editor.style.display = 'block';

  document.getElementById('editor-label').textContent = meta.label;
  document.getElementById('editor-type').textContent = `${meta.tag}${meta.type ? ` (type="${meta.type}")` : ''}`;

  const suggestedName = meta.label && meta.label !== '(bez etykiety)' ? meta.label : '';
  document.getElementById('editor-display-name').value = suggestedName;
  document.getElementById('editor-value').value = meta.currentValue || '';

  const valueRow = document.getElementById('editor-value-row');
  const selectRow = document.getElementById('editor-select-row');
  if (meta.isSelect && meta.options) {
    valueRow.style.display = 'none';
    selectRow.style.display = 'block';
    const sel = document.getElementById('editor-select');
    sel.innerHTML = meta.options.map(o => `<option value="${escapeAttr(o.value)}">${escapeHtml(o.text)}</option>`).join('');
    sel.value = meta.currentValue;
  } else {
    valueRow.style.display = 'block';
    selectRow.style.display = 'none';
  }

  setTimeout(() => document.getElementById('editor-display-name').focus(), 50);
}

function hideFieldEditor() {
  document.getElementById('field-editor').style.display = 'none';
}

async function savePendingField() {
  if (!state.pendingField || !state.recordingSession) return;
  const displayName = document.getElementById('editor-display-name').value.trim();
  if (!displayName) {
    alert('Podaj nazwę pola w szablonie.');
    document.getElementById('editor-display-name').focus();
    return;
  }
  const value = state.pendingField.meta.isSelect
    ? document.getElementById('editor-select').value
    : document.getElementById('editor-value').value;

  state.recordingSession.steps.push({
    type: 'fill',
    pageUrl: state.recordingSession.currentPageUrl,
    signature: state.pendingField.signature,
    label: displayName,
    value
  });
  await saveRecordingSession();

  await sendToContent({ type: 'MARK_FIELD_RECORDED', signature: state.pendingField.signature });

  state.pendingField = null;
  hideFieldEditor();
  renderRecordedSteps();
  document.getElementById('btn-finish-recording').disabled = false;
}

function cancelPendingField() {
  state.pendingField = null;
  hideFieldEditor();
  // Wyczyść pulsowanie pending na stronie, zostaw nagrane
  sendToContent({ type: 'CLEAR_RECORDED_MARKS' }).then(async () => {
    if (!state.recordingSession) return;
    for (const step of state.recordingSession.steps) {
      if (step.type === 'fill' && step.pageUrl === state.recordingSession.currentPageUrl) {
        await sendToContent({ type: 'MARK_FIELD_RECORDED', signature: step.signature });
      } else if (step.type === 'click' && step.pageUrl === state.recordingSession.currentPageUrl) {
        await sendToContent({ type: 'MARK_NAV_RECORDED', signature: step.signature });
      }
    }
  });
}

// === NAV EDITOR ===

function onNavSelected(msg) {
  // Sidepanel żyje przez nawigację strony — zapisuje pending_nav_click do session storage
  // zanim strona zdąży się przeładować. onNavigationOccurred użyje tych danych.
  chrome.storage.session.set({
    pending_nav_click: {
      signature: msg.signature,
      meta: msg.meta,
      pageUrl: msg.pageUrl || state.recordingSession?.currentPageUrl,
      capturedAt: Date.now()
    }
  });
}

function showNavEditor(meta) {
  hideFieldEditor();
  const editor = document.getElementById('nav-editor');
  editor.style.display = 'block';
  document.getElementById('nav-editor-label').textContent = meta.label;
  document.getElementById('nav-editor-display-name').value = meta.label && meta.label !== '(bez etykiety)' ? `Przejdź: ${meta.label}` : 'Przejdź dalej';
  setTimeout(() => document.getElementById('nav-editor-display-name').focus(), 50);
}

function hideNavEditor() {
  document.getElementById('nav-editor').style.display = 'none';
}

async function savePendingNav() {
  if (!state.recordingSession) return;
  const displayName = document.getElementById('nav-editor-display-name').value.trim() || 'Przejdź dalej';

  // Krok click został już dodany przez onNavigationOccurred — zaktualizuj tylko etykietę
  if (state.pendingNavRename !== null) {
    state.recordingSession.steps[state.pendingNavRename].label = displayName;
    state.pendingNavRename = null;
    await saveRecordingSession();
  }

  hideNavEditor();
  renderRecordedSteps();
  // Aktywuj recording-fields na nowej stronie. Wysyłamy tu (a nie tylko w 50ms timerze),
  // bo content script jest na pewno gotowy — user zdążył przeczytać i kliknąć edytor.
  await sendToContent({ type: 'START_RECORDING_FIELDS' });
}

function cancelPendingNav() {
  // Krok click jest już zapisany z domyślną etykietą — "Pomiń" tylko zamyka edytor
  state.pendingNavRename = null;
  hideNavEditor();
  sendToContent({ type: 'START_RECORDING_FIELDS' });
}

// === RENDER STEPS LIST ===

function renderRecordedSteps() {
  if (!state.recordingSession) return;
  const list = document.getElementById('recorded-fields');
  const steps = state.recordingSession.steps;

  if (steps.length === 0) {
    list.innerHTML = '';
    return;
  }

  // Grupuj po pageUrl - rysuj separator między stronami
  let lastPage = null;
  let pageNum = 0;
  const html = [];

  steps.forEach((step, i) => {
    if (step.pageUrl !== lastPage) {
      pageNum++;
      lastPage = step.pageUrl;
      if (pageNum > 1) {
        html.push(`<div class="recorded-field is-page-break">— Strona ${pageNum} —</div>`);
      }
    }

    if (step.type === 'fill') {
      html.push(`
        <div class="recorded-field">
          <div class="recorded-field-num">${i + 1}</div>
          <div class="recorded-field-info">
            <div class="recorded-field-name">${escapeHtml(step.label)}</div>
            <div class="recorded-field-value">→ ${escapeHtml(String(step.value || '(puste)'))}</div>
          </div>
          <button class="icon-btn danger" data-remove="${i}" title="Usuń">✕</button>
        </div>
      `);
    } else if (step.type === 'click') {
      html.push(`
        <div class="recorded-field is-nav">
          <div class="recorded-field-num">→</div>
          <div class="recorded-field-info">
            <div class="recorded-field-name">${escapeHtml(step.label)}</div>
            <div class="recorded-field-value">${step.waitForNavigation ? 'czeka na nową stronę' : 'klik bez nawigacji'}</div>
          </div>
          <button class="icon-btn danger" data-remove="${i}" title="Usuń">✕</button>
        </div>
      `);
    }
  });

  list.innerHTML = html.join('');

  list.querySelectorAll('[data-remove]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const idx = parseInt(btn.dataset.remove, 10);
      state.recordingSession.steps.splice(idx, 1);
      await saveRecordingSession();
      renderRecordedSteps();
      const hasFill = state.recordingSession.steps.some(s => s.type === 'fill');
      document.getElementById('btn-finish-recording').disabled = !hasFill;
    });
  });
}

async function finishRecording() {
  if (!state.recordingSession) return;
  if (!state.recordingSession.steps.some(s => s.type === 'fill')) return;

  await sendToContent({ type: 'STOP_RECORDING' });

  document.getElementById('save-name').value = '';
  document.getElementById('save-url').value = state.recordingSession.firstPageUrl || '';
  const fills = state.recordingSession.steps.filter(s => s.type === 'fill').length;
  const clicks = state.recordingSession.steps.filter(s => s.type === 'click').length;
  document.getElementById('save-summary').textContent =
    `${fills} pól · ${clicks} przejść między stronami · ${clicks + 1} stron${clicks === 0 ? 'a' : ''}`;

  switchView('save');
  setTimeout(() => document.getElementById('save-name').focus(), 50);
}

async function saveTemplate() {
  if (!state.recordingSession) return;
  const name = document.getElementById('save-name').value.trim();
  const matchUrl = document.getElementById('save-url').value.trim();

  if (!name) {
    alert('Podaj nazwę szablonu.');
    return;
  }

  const template = {
    id: 'tpl_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8),
    name,
    matchUrl: matchUrl || state.recordingSession.firstPageUrl,
    createdAt: new Date().toISOString(),
    steps: state.recordingSession.steps
  };

  const { templates = [] } = await chrome.storage.local.get('templates');
  templates.push(template);
  await chrome.storage.local.set({ templates });

  await sendToContent({ type: 'CLEAR_RECORDED_MARKS' });
  state.recordingSession = null;
  state.pendingField = null;
  state.pendingNavRename = null;
  await saveRecordingSession();

  await refreshTemplatesUI();
  chrome.runtime.sendMessage({ type: 'REFRESH_BADGE' });
  switchView('home');
}

// ============ PLAYBACK ============

async function applyMatchingTemplate() {
  if (state.matchingTemplates.length === 0) return;
  await applyTemplate(state.matchingTemplates[0]);
}

async function applyTemplate(template) {
  // Sprawdź czy jesteśmy na właściwej stronie początkowej szablonu.
  // Uruchomienie playbacku na innej stronie grozi wpisaniem wartości w błędne pola
  // (sygnatury mogą się częściowo dopasować do podobnych pól na innej stronie).
  const firstFill = template.steps.find(s => s.type === 'fill');
  if (firstFill?.pageUrl && state.currentUrl) {
    const normalize = url => url.split('?')[0].replace(/\/+$/, '');
    if (normalize(firstFill.pageUrl) !== normalize(state.currentUrl)) {
      const ok = confirm(
        `Szablon był nagrany zaczynając od:\n${firstFill.pageUrl}\n\nAktualna strona:\n${state.currentUrl}\n\nPola mogą zostać wpisane w błędnych miejscach. Kontynuować?`
      );
      if (!ok) return;
    }
  }

  state.playbackSession = {
    tabId: state.currentTab,
    kind: 'playback',
    templateId: template.id,
    template, // pełna kopia żeby przeżyła nawet usunięcie szablonu
    stepIndex: 0,
    paused: false,
    awaitingNavConfirm: false,
    log: []
  };
  await savePlaybackSession();

  switchView('playback');
  renderPlaybackUI();

  await sendToContent({ type: 'CLEAR_PLAYBACK_HIGHLIGHTS' });

  // Krótka pauza wizualna, potem wykonaj
  setTimeout(() => continuePlayback(), 300);
}

function renderPlaybackUI() {
  const pb = state.playbackSession;
  if (!pb) return;
  document.getElementById('pb-template-name').textContent = pb.template.name;

  const total = pb.template.steps.length;
  const done = pb.stepIndex;
  document.getElementById('pb-progress-text').textContent = `krok ${Math.min(done, total)} z ${total}`;
  document.getElementById('pb-progress-fill').style.width = `${total > 0 ? Math.min(done, total) / total * 100 : 0}%`;

  // Log
  const logEl = document.getElementById('pb-step-log');
  logEl.innerHTML = pb.log.map(item => {
    const cls = item.kind === 'nav' ? 'nav' : (item.ok ? 'ok' : 'fail');
    const value = item.value !== undefined ? `<span class="pb-log-value">${escapeHtml(String(item.value))}</span>` :
                  (item.reason ? `<span class="pb-log-value">${escapeHtml(item.reason)}</span>` : '');
    return `<div class="pb-log-item ${cls}"><span class="pb-log-label">${escapeHtml(item.label)}</span>${value}</div>`;
  }).join('');

  // Status / confirm cards
  document.getElementById('pb-confirm-nav').style.display = pb.awaitingNavConfirm ? 'block' : 'none';
  document.getElementById('pb-paused').style.display = pb.paused && !pb.awaitingNavConfirm ? 'block' : 'none';
  document.getElementById('pb-final').style.display = 'none';
  document.getElementById('pb-final-actions').style.display = 'none';

  if (pb.awaitingNavConfirm) {
    const navStep = pb.template.steps[pb.stepIndex];
    document.getElementById('pb-nav-label').textContent = navStep?.label || 'Dalej';
  }

  if (!pb.paused && !pb.awaitingNavConfirm && pb.stepIndex < pb.template.steps.length) {
    document.getElementById('pb-status').textContent = `Wykonuję krok ${pb.stepIndex + 1}…`;
  }
}

async function continuePlayback() {
  const pb = state.playbackSession;
  if (!pb || pb.paused || pb.awaitingNavConfirm) return;

  if (pb.stepIndex >= pb.template.steps.length) {
    return finalizePlayback();
  }

  const step = pb.template.steps[pb.stepIndex];

  if (step.type === 'fill') {
    document.getElementById('pb-status').textContent = `Wypełniam: ${step.label}…`;
    const result = await sendToContent({ type: 'PLAYBACK_FILL_STEP', step });
    if (result?.ok) {
      pb.log.push({ kind: 'fill', ok: true, label: step.label, value: step.value });
    } else {
      pb.log.push({ kind: 'fill', ok: false, label: step.label, reason: result?.reason || 'błąd' });
    }
    pb.stepIndex++;
    await savePlaybackSession();
    renderPlaybackUI();
    // Małe opóźnienie między fillami żeby user widział co się dzieje
    setTimeout(() => continuePlayback(), 150);
  } else if (step.type === 'click') {
    // Nawigacja — pauza na potwierdzenie
    pb.awaitingNavConfirm = true;
    await savePlaybackSession();
    renderPlaybackUI();
  }
}

async function confirmNavAndContinue() {
  const pb = state.playbackSession;
  if (!pb || !pb.awaitingNavConfirm) return;
  const step = pb.template.steps[pb.stepIndex];
  pb.awaitingNavConfirm = false;
  await savePlaybackSession();
  renderPlaybackUI();

  document.getElementById('pb-status').textContent = `Klikam: ${step.label}…`;

  const result = await sendToContent({ type: 'PLAYBACK_CLICK_STEP', step });
  if (result?.ok) {
    pb.log.push({ kind: 'nav', ok: true, label: step.label });
  } else {
    pb.log.push({ kind: 'nav', ok: false, label: step.label, reason: result?.reason || 'nie udało się kliknąć' });
    // Klik się nie udał - zatrzymaj
    pb.stepIndex++;
    await savePlaybackSession();
    return finalizePlayback();
  }

  pb.stepIndex++;
  await savePlaybackSession();
  renderPlaybackUI();

  if (step.waitForNavigation) {
    document.getElementById('pb-status').textContent = 'Czekam na załadowanie nowej strony…';
    // Po reload (opcja A) — sidepanel restoruje się przez restoreFromSession.
    // Dla SPA / no-nav (B/C) — nic się nie wydarzy, ale waitForStableDom zwróci ok.
    const stableResult = await sendToContent({ type: 'PLAYBACK_WAIT_STABLE', timeoutMs: 5000 });

    if (!stableResult?.ok) {
      // Timeout - daj userowi możliwość kontynuacji ręcznej
      pb.paused = true;
      await savePlaybackSession();
      document.getElementById('pb-status').textContent = 'Strona nie ustabilizowała się — wstrzymano.';
      renderPlaybackUI();
      return;
    }
    // Krótka dodatkowa pauza dla SPA frameworków
    setTimeout(() => continuePlayback(), 300);
  } else {
    setTimeout(() => continuePlayback(), 300);
  }
}

async function pausePlayback() {
  const pb = state.playbackSession;
  if (!pb) return;
  pb.paused = true;
  pb.awaitingNavConfirm = false;
  await savePlaybackSession();
  renderPlaybackUI();
}

async function resumePlayback() {
  const pb = state.playbackSession;
  if (!pb) return;
  pb.paused = false;
  await savePlaybackSession();
  renderPlaybackUI();
  setTimeout(() => continuePlayback(), 100);
}

async function stopPlayback() {
  await finalizePlayback();
}

async function finalizePlayback() {
  const pb = state.playbackSession;
  if (!pb) return switchView('home');

  const fills = pb.log.filter(l => l.kind === 'fill');
  const ok = fills.filter(l => l.ok).length;
  const fail = fills.filter(l => !l.ok).length;
  const navOk = pb.log.filter(l => l.kind === 'nav' && l.ok).length;

  const summary = document.getElementById('pb-final');
  summary.style.display = 'block';
  document.getElementById('pb-status').textContent = 'Zakończono.';

  if (fail === 0 && ok > 0) {
    summary.className = 'result-summary success';
    summary.textContent = `✓ Wypełniono wszystkie ${ok} pól przez ${navOk + 1} stron${(navOk + 1) === 1 ? 'ę' : 'y'}. Sprawdź wartości i zapisz formularz w aplikacji.`;
  } else if (ok > 0) {
    summary.className = 'result-summary partial';
    summary.textContent = `Wypełniono ${ok} z ${ok + fail} pól. ${fail} pól nie znaleziono — może zmieniła się struktura strony.`;
  } else {
    summary.className = 'result-summary partial';
    summary.textContent = 'Nie udało się wypełnić żadnego pola.';
  }

  document.getElementById('pb-final-actions').style.display = 'flex';

  state.playbackSession = null;
  await savePlaybackSession();
}

async function finishPlayback() {
  await sendToContent({ type: 'CLEAR_PLAYBACK_HIGHLIGHTS' });
  switchView('home');
}

// === NAVIGATION OCCURRED (z background) ===

async function onNavigationOccurred(msg) {
  if (state.recordingSession && msg.tabId === state.recordingSession.tabId) {
    // Sprawdź czy jest pending_nav_click zapisany przez content.js przed nawigacją
    const stored = await chrome.storage.session.get('pending_nav_click');
    const pendingNavClick = stored.pending_nav_click;

    if (pendingNavClick) {
      const defaultLabel = pendingNavClick.meta?.label || 'Przejdź dalej';
      state.recordingSession.steps.push({
        type: 'click',
        pageUrl: pendingNavClick.pageUrl,
        signature: pendingNavClick.signature,
        label: defaultLabel,
        waitForNavigation: true
      });
      state.pendingNavRename = state.recordingSession.steps.length - 1;
      await chrome.storage.session.remove('pending_nav_click');
    }

    state.recordingSession.currentPageUrl = msg.url;
    state.recordingSession.activeMode = 'fields';
    await saveRecordingSession();

    document.getElementById('rec-page-url').textContent = msg.url || '—';
    document.getElementById('rec-sub-text').textContent = 'Nowa strona — klikaj kolejne pola.';
    renderRecordedSteps();

    if (pendingNavClick) {
      showNavEditor({ label: pendingNavClick.meta?.label || 'Przejdź dalej' });
      // Mała pauza — content script może dopiero teraz odbierać SESSION_RESUME
      setTimeout(() => sendToContent({ type: 'START_RECORDING_FIELDS' }), 50);
    }
  }
  // Dla playback nic nie robimy — continuePlayback i tak czeka na waitForStableDom.
}

// ============ HELPERS ============

function sendToContent(payload) {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]?.id) return resolve(null);
      chrome.tabs.sendMessage(tabs[0].id, payload, (response) => {
        if (chrome.runtime.lastError) {
          resolve(null);
        } else {
          resolve(response);
        }
      });
    });
  });
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

function escapeAttr(s) {
  return String(s).replace(/"/g, '&quot;');
}
