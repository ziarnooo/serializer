# Form Template Filler

Chrome extension (Manifest V3) do nagrywania i odtwarzania szablonów wypełniania formularzy. Działa **w pełni lokalnie** — zero sieci, dane w `chrome.storage`. Wbudowane w Side Panel.

**Use case:** lekarze wypełniający dokumentację medyczną w EDM-ach. Szablon to "pomiary kontrolne dla zdrowego dorosłego" → 1 klik = wypełnione 14 pól na 3 stronach, lekarz weryfikuje i sam klika "Zapisz".

## Wersja

`0.2.0` — multi-page recording + playback.

Co dostała v0.2 vs v0.1:
- ✅ Nagrywanie szablonów rozłożonych na **wiele stron** (formularz 3-stronicowy itp.).
- ✅ Wsparcie dla **trzech typów nawigacji** (full URL reload / SPA history / no-nav wizard).
- ✅ Pauza-i-potwierdź przed każdym klikiem nawigacyjnym podczas odtwarzania.
- ✅ Wskrzeszenie sesji nagrywania/odtwarzania po przeładowaniu strony.
- ✅ Test form 3-stronicowy (`test-form-multi/`).

## Szybki start

1. Otwórz `chrome://extensions`, włącz **Tryb dewelopera**.
2. **"Załaduj rozpakowane"** → wskaż folder repo.
3. Otwórz `test-form-multi/page1.html` w nowej karcie.
4. Klik ikony wtyczki → otwiera się Side Panel.
5. **"Nagraj nowy szablon"** → klikaj pola, dla każdego wpisuj wartość.
6. **"→ Nagraj przejście dalej"** → klik "Dalej" na stronie → potwierdzasz.
7. Powtarzaj na kolejnych stronach.
8. **"Zapisz szablon"** → nazwa, URL pattern.
9. Wróć na page1.html (F5) → Side Panel pokazuje pasujący szablon → **"Wypełnij formularz"**.

## Dokumentacja

Cała w `docs/`:

- [`CLAUDE.md`](./CLAUDE.md) — szybka orientacja dla Claude Code (zacznij tu jeśli pracujesz w CC).
- [`docs/ARCHITECTURE.md`](./docs/ARCHITECTURE.md) — komponenty, przepływ wiadomości, storage.
- [`docs/DATA_MODEL.md`](./docs/DATA_MODEL.md) — format Template, Step, Signature.
- [`docs/FIELD_MATCHING.md`](./docs/FIELD_MATCHING.md) — strategia 6-warstwowego matchingu pól.
- [`docs/MULTI_PAGE.md`](./docs/MULTI_PAGE.md) — opcje A/B/C nawigacji, wskrzeszanie sesji.
- [`docs/DEVELOPMENT.md`](./docs/DEVELOPMENT.md) — load, debug każdy komponent osobno.
- [`docs/ROADMAP.md`](./docs/ROADMAP.md) — co dalej, co odrzucone i dlaczego.

## Kluczowe zasady (z bezpieczeństwa medycznego)

1. Wtyczka **nie klika** "Zapisz" — lekarz robi to sam.
2. Wszystkie wypełnione pola podświetlone na **żółto** — wymuszona weryfikacja.
3. Każde przejście między stronami wymaga **potwierdzenia** w panelu.
4. **Zero sieci.** Brak telemetrii, brak crash reporting, brak LLM.
5. Dane szablonów to **wartości typowe**, nie dane konkretnego pacjenta.

## Stack

- Vanilla JS (brak frameworków, brak buildu).
- Manifest V3.
- Chrome Side Panel API.
- `chrome.storage.local` + `chrome.storage.session`.

## Licencja

Internal / not yet decided. Domyślnie all rights reserved (Dominik / MasterBorn).
