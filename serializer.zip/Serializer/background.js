// ============================================
// Serializer - Background Service Worker
// ============================================
// Odpowiedzialność:
// - Otwieranie side panel na klik w ikonę
// - Aktualizacja badge na podstawie pasujących templates
// - Wykrywanie nawigacji (webNavigation) i powiadamianie content scriptu/sidepanel
//   o tym, żeby wznowił sesję recording/playback po przeładowaniu strony
// - Przekazywanie wiadomości

const SESSION_KEYS = {
  RECORDING: 'session_recording',
  PLAYBACK: 'session_playback'
};

chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true })
    .catch((error) => console.error('Side panel setup error:', error));
});

// ============ BADGE ============

chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  await updateBadgeForTab(tabId);
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo) => {
  if (changeInfo.status === 'complete') {
    await updateBadgeForTab(tabId);
  }
});

async function updateBadgeForTab(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    if (!tab.url || tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://')) {
      chrome.action.setBadgeText({ text: '', tabId });
      return;
    }

    const { templates = [] } = await chrome.storage.local.get('templates');
    const matching = templates.filter(t => urlMatches(tab.url, t.matchUrl));

    if (matching.length > 0) {
      chrome.action.setBadgeText({ text: String(matching.length), tabId });
      chrome.action.setBadgeBackgroundColor({ color: '#2563eb', tabId });
    } else {
      chrome.action.setBadgeText({ text: '', tabId });
    }
  } catch (e) {
    // Tab może być zamknięty
  }
}

function urlMatches(url, pattern) {
  if (!pattern || !url) return false;
  try {
    const regex = new RegExp('^' + pattern.replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*') + '$');
    return regex.test(url);
  } catch {
    return url === pattern;
  }
}

// ============ NAWIGACJA — WSKRZESZANIE SESJI ============
// Gdy strona się przeładuje (opcja A — pełne reload URL), content script umiera.
// Po załadowaniu nowego content scriptu (event onCompleted) sprawdzamy czy mamy
// aktywną sesję recording/playback dla tej karty i informujemy zarówno content
// script (żeby się reaktywował) jak i sidepanel (żeby zaktualizował UI).

chrome.webNavigation.onCompleted.addListener(async (details) => {
  if (details.frameId !== 0) return; // tylko top frame

  const session = await getSessionForTab(details.tabId);
  if (!session) return;

  // Daj content script chwilę żeby się załadował, potem powiadom
  setTimeout(() => {
    chrome.tabs.sendMessage(details.tabId, {
      type: 'SESSION_RESUME',
      session
    }).catch(() => {/* content script może jeszcze nie być gotowy */});

    // Powiadom też side panel o nawigacji (do aktualizacji UI postępu)
    chrome.runtime.sendMessage({
      type: 'NAVIGATION_OCCURRED',
      tabId: details.tabId,
      url: details.url,
      session
    }).catch(() => {/* sidepanel może być zamknięty */});
  }, 200);
});

// Również SPA history-based navigation (pushState/replaceState)
chrome.webNavigation.onHistoryStateUpdated.addListener(async (details) => {
  if (details.frameId !== 0) return;

  const session = await getSessionForTab(details.tabId);
  if (!session) return;

  // SPA: content script żyje, ale URL się zmienił. Powiadom o nawigacji.
  chrome.tabs.sendMessage(details.tabId, {
    type: 'SPA_NAVIGATION',
    url: details.url
  }).catch(() => {});

  chrome.runtime.sendMessage({
    type: 'NAVIGATION_OCCURRED',
    tabId: details.tabId,
    url: details.url,
    session,
    spa: true
  }).catch(() => {});
});

async function getSessionForTab(tabId) {
  const data = await chrome.storage.session.get([SESSION_KEYS.RECORDING, SESSION_KEYS.PLAYBACK]);
  const rec = data[SESSION_KEYS.RECORDING];
  const pb = data[SESSION_KEYS.PLAYBACK];
  if (rec && rec.tabId === tabId) return { kind: 'recording', ...rec };
  if (pb && pb.tabId === tabId) return { kind: 'playback', ...pb };
  return null;
}

// ============ PRZEKAZYWANIE WIADOMOŚCI ============

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'GET_ACTIVE_TAB') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      sendResponse({ url: tabs[0]?.url, tabId: tabs[0]?.id });
    });
    return true;
  }

  if (message.type === 'REFRESH_BADGE') {
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      if (tabs[0]?.id) await updateBadgeForTab(tabs[0].id);
      sendResponse({ ok: true });
    });
    return true;
  }
});
