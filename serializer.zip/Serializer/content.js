// ============================================
// Serializer - Content Script (v2)
// ============================================
// Tryby:
//   'idle'                  — nic się nie dzieje
//   'recording-fields'      — czeka na kliknięcie pola formularza
//   'recording-nav'         — czeka na kliknięcie elementu nawigacyjnego (np. Dalej)
//   'playback'              — w trakcie odtwarzania (sterowane głównie z sidepanelu)
//
// Komunikacja:
//   - Sidepanel → content: START_RECORDING_FIELDS, STOP_RECORDING,
//                          START_RECORDING_NAV_CLICK, MARK_FIELD_RECORDED,
//                          MARK_NAV_RECORDED, CLEAR_RECORDED_MARKS,
//                          PLAYBACK_FILL_STEP, PLAYBACK_CLICK_STEP,
//                          PLAYBACK_WAIT_STABLE, CLEAR_PLAYBACK_HIGHLIGHTS,
//                          GET_PAGE_INFO
//   - Content → sidepanel:  FIELD_SELECTED, NAV_ELEMENT_SELECTED (bez preventDefault),
//                           RECORDING_CANCELLED
//   - Background → content: SESSION_RESUME (po reload), SPA_NAVIGATION

(function() {
  'use strict';

  if (window.__formTemplateFillerLoaded) return;
  window.__formTemplateFillerLoaded = true;

  let mode = 'idle';
  let hoverTarget = null;

  // ============ KOMUNIKACJA ============

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    try {
      switch (msg.type) {
        case 'START_RECORDING_FIELDS':
          startRecordingFields();
          sendResponse({ ok: true });
          break;
        case 'START_RECORDING_NAV_CLICK':
          startRecordingNavClick();
          sendResponse({ ok: true });
          break;
        case 'STOP_RECORDING':
          stopRecording();
          sendResponse({ ok: true });
          break;
        case 'MARK_FIELD_RECORDED':
          markFieldAsRecorded(msg.signature);
          sendResponse({ ok: true });
          break;
        case 'MARK_NAV_RECORDED':
          markNavAsRecorded(msg.signature);
          sendResponse({ ok: true });
          break;
        case 'CLEAR_RECORDED_MARKS':
          clearAllRecordedMarks();
          sendResponse({ ok: true });
          break;
        case 'PLAYBACK_FILL_STEP':
          sendResponse(playbackFillStep(msg.step));
          break;
        case 'PLAYBACK_CLICK_STEP':
          playbackClickStep(msg.step).then(r => sendResponse(r));
          return true;
        case 'PLAYBACK_WAIT_STABLE':
          waitForStableDom(msg.timeoutMs || 5000).then(r => sendResponse(r));
          return true;
        case 'CLEAR_PLAYBACK_HIGHLIGHTS':
          clearPlaybackHighlights();
          sendResponse({ ok: true });
          break;
        case 'GET_PAGE_INFO':
          sendResponse({ url: location.href, title: document.title, readyState: document.readyState });
          break;
        case 'SESSION_RESUME':
          handleSessionResume(msg.session);
          sendResponse({ ok: true });
          break;
        case 'SPA_NAVIGATION':
          handleSpaNavigation(msg.url);
          sendResponse({ ok: true });
          break;
      }
    } catch (e) {
      sendResponse({ error: e.message });
    }
    return false;
  });

  // ============ RECORDING — POLA ============

  function startRecordingFields() {
    enterRecordingMode('recording-fields');
    showStatusBanner('🔴 Tryb nagrywania pól — kliknij pole formularza. ESC = zakończ.');
  }

  function startRecordingNavClick() {
    enterRecordingMode('recording-nav');
    showStatusBanner('🟣 Wskaż przycisk nawigacyjny (np. „Dalej") — kliknij go raz. ESC = anuluj.');
  }

  function enterRecordingMode(newMode) {
    stopRecording(); // wyczyść poprzedni stan listenerów
    mode = newMode;
    document.body.classList.add('ftf-recording-mode');
    document.addEventListener('mousemove', onHover, true);
    document.addEventListener('click', onRecordClick, true);
    document.addEventListener('keydown', onEscape, true);
  }

  function stopRecording() {
    mode = 'idle';
    document.body.classList.remove('ftf-recording-mode');
    document.removeEventListener('mousemove', onHover, true);
    document.removeEventListener('click', onRecordClick, true);
    document.removeEventListener('keydown', onEscape, true);
    clearHover();
    hideStatusBanner();
  }

  function onEscape(e) {
    if (e.key === 'Escape') {
      e.preventDefault();
      e.stopPropagation();
      const wasMode = mode;
      stopRecording();
      chrome.runtime.sendMessage({ type: 'RECORDING_CANCELLED', wasMode });
    }
  }

  function onHover(e) {
    if (mode !== 'recording-fields' && mode !== 'recording-nav') return;
    const target = mode === 'recording-fields'
      ? resolveFormField(e.target)
      : resolveClickable(e.target);
    if (target === hoverTarget) return;
    clearHover();
    if (target) {
      hoverTarget = target;
      target.classList.add(mode === 'recording-fields' ? 'ftf-hover-highlight' : 'ftf-hover-nav-highlight');
    }
  }

  function clearHover() {
    if (hoverTarget) {
      hoverTarget.classList.remove('ftf-hover-highlight', 'ftf-hover-nav-highlight');
      hoverTarget = null;
    }
  }

  function onRecordClick(e) {
    if (mode === 'recording-fields') {
      const field = resolveFormField(e.target);
      if (!field) {
        flashWarning('To nie jest pole formularza. Kliknij input, textarea lub select.');
        e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
        return;
      }
      e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
      document.querySelectorAll('.ftf-pending-highlight').forEach(el => el.classList.remove('ftf-pending-highlight'));
      field.classList.add('ftf-pending-highlight');
      chrome.runtime.sendMessage({
        type: 'FIELD_SELECTED',
        signature: buildFieldSignature(field),
        meta: inspectField(field)
      });
    } else if (mode === 'recording-nav') {
      const clickable = resolveClickable(e.target);
      if (!clickable) {
        flashWarning('To nie jest klikalny element. Wskaż przycisk lub link.');
        e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
        return;
      }
      // Wyślij sygnaturę do sidepanelu — sidepanel zapisze ją do session storage.
      // Robimy to przez sidepanel (a nie bezpośrednio przez storage.set) bo sidepanel
      // żyje przez nawigację strony i gwarantuje zapis przed NAVIGATION_OCCURRED.
      // Nie blokujemy eventu — nawigacja odbywa się naturalnie (form submit, link itp.).
      const signature = buildClickableSignature(clickable);
      const meta = inspectClickable(clickable);
      chrome.runtime.sendMessage({
        type: 'NAV_ELEMENT_SELECTED',
        signature,
        meta,
        pageUrl: location.href
      });
      stopRecording(); // zdejmij listenery przed nawigacją
      // Brak preventDefault — event kontynuuje, strona nawiguje
    }
  }

  function resolveFormField(el) {
    if (!el) return null;
    if (el.tagName === 'LABEL') {
      const forId = el.getAttribute('for');
      if (forId) {
        const target = document.getElementById(forId);
        if (target) return target;
      }
      const innerInput = el.querySelector('input, textarea, select');
      if (innerInput) return innerInput;
    }
    if (['INPUT', 'TEXTAREA', 'SELECT'].includes(el.tagName)) {
      if (el.type === 'hidden' || el.type === 'submit' || el.type === 'button' || el.type === 'reset') return null;
      return el;
    }
    let parent = el.parentElement;
    let depth = 0;
    while (parent && depth < 3) {
      const inner = parent.querySelector('input:not([type="hidden"]), textarea, select');
      if (inner && parent.contains(inner)) return inner;
      parent = parent.parentElement;
      depth++;
    }
    return null;
  }

  function resolveClickable(el) {
    // Element nawigacyjny: <button>, <a>, [role="button"], submit/button input,
    // albo dowolny element z onclick.
    if (!el) return null;
    let cur = el;
    let depth = 0;
    while (cur && cur !== document.body && depth < 5) {
      const tag = cur.tagName;
      if (tag === 'BUTTON' || tag === 'A') return cur;
      if (tag === 'INPUT' && (cur.type === 'submit' || cur.type === 'button')) return cur;
      if (cur.getAttribute && cur.getAttribute('role') === 'button') return cur;
      cur = cur.parentElement;
      depth++;
    }
    return null;
  }

  function buildFieldSignature(el) {
    return {
      tag: el.tagName.toLowerCase(),
      type: el.type || null,
      id: el.id || null,
      name: el.getAttribute('name') || null,
      placeholder: el.getAttribute('placeholder') || null,
      ariaLabel: el.getAttribute('aria-label') || null,
      labelText: findLabelText(el),
      formIndex: getFormFieldIndex(el),
      stablePath: buildStablePath(el)
    };
  }

  function buildClickableSignature(el) {
    return {
      tag: el.tagName.toLowerCase(),
      type: el.type || null,
      id: el.id || null,
      name: el.getAttribute('name') || null,
      ariaLabel: el.getAttribute('aria-label') || null,
      // Tekst widoczny — ważny sygnał dla guzików typu "Dalej"
      visibleText: (el.textContent || '').trim().slice(0, 80),
      // href tylko dla <a>
      href: el.tagName === 'A' ? el.getAttribute('href') : null,
      stablePath: buildStablePath(el)
    };
  }

  function inspectField(el) {
    return {
      tag: el.tagName.toLowerCase(),
      type: el.type || null,
      label: findLabelText(el) || el.getAttribute('aria-label') || el.getAttribute('placeholder') || el.getAttribute('name') || el.id || '(bez etykiety)',
      currentValue: el.value || '',
      isSelect: el.tagName === 'SELECT',
      options: el.tagName === 'SELECT' ? Array.from(el.options).map(o => ({ value: o.value, text: o.textContent })) : null
    };
  }

  function inspectClickable(el) {
    return {
      tag: el.tagName.toLowerCase(),
      label: (el.textContent || '').trim().slice(0, 80) || el.getAttribute('aria-label') || el.value || '(bez etykiety)'
    };
  }

  function findLabelText(el) {
    if (el.id) {
      const label = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
      if (label) return label.textContent.trim();
    }
    let parent = el.parentElement;
    while (parent && parent.tagName !== 'FORM' && parent !== document.body) {
      if (parent.tagName === 'LABEL') {
        return parent.textContent.replace(el.value || '', '').trim();
      }
      parent = parent.parentElement;
    }
    const labelledBy = el.getAttribute('aria-labelledby');
    if (labelledBy) {
      const labelEl = document.getElementById(labelledBy);
      if (labelEl) return labelEl.textContent.trim();
    }
    return null;
  }

  function getFormFieldIndex(el) {
    const form = el.closest('form') || document.body;
    const fields = Array.from(form.querySelectorAll('input:not([type="hidden"]), textarea, select'));
    return fields.indexOf(el);
  }

  function buildStablePath(el) {
    const path = [];
    let current = el;
    while (current && current !== document.body && path.length < 6) {
      let part = current.tagName.toLowerCase();
      if (current.id && !/\d{4,}/.test(current.id)) {
        part = `#${CSS.escape(current.id)}`;
        path.unshift(part);
        break;
      }
      if (current.getAttribute && current.getAttribute('name')) {
        part += `[name="${current.getAttribute('name')}"]`;
      }
      const parent = current.parentElement;
      if (parent) {
        const siblings = Array.from(parent.children).filter(c => c.tagName === current.tagName);
        if (siblings.length > 1) {
          const idx = siblings.indexOf(current);
          part += `:nth-of-type(${idx + 1})`;
        }
      }
      path.unshift(part);
      current = current.parentElement;
    }
    return path.join(' > ');
  }

  function markFieldAsRecorded(signature) {
    document.querySelectorAll('.ftf-pending-highlight').forEach(el => {
      el.classList.remove('ftf-pending-highlight');
      el.classList.add('ftf-recorded-highlight');
    });
  }

  function markNavAsRecorded(signature) {
    document.querySelectorAll('.ftf-pending-nav-highlight').forEach(el => {
      el.classList.remove('ftf-pending-nav-highlight');
      el.classList.add('ftf-recorded-nav-highlight');
    });
  }

  function clearAllRecordedMarks() {
    document.querySelectorAll(
      '.ftf-recorded-highlight, .ftf-pending-highlight, ' +
      '.ftf-recorded-nav-highlight, .ftf-pending-nav-highlight'
    ).forEach(el => {
      el.classList.remove(
        'ftf-recorded-highlight', 'ftf-pending-highlight',
        'ftf-recorded-nav-highlight', 'ftf-pending-nav-highlight'
      );
    });
  }

  // ============ PLAYBACK ============

  function playbackFillStep(step) {
    const field = findFieldBySignature(step.signature);
    if (!field) return { ok: false, reason: 'Nie znaleziono pola', label: step.label };
    try {
      setFieldValue(field, step.value);
      field.classList.add('ftf-filled-highlight');
      return { ok: true, label: step.label, value: step.value };
    } catch (e) {
      return { ok: false, reason: e.message, label: step.label };
    }
  }

  async function playbackClickStep(step) {
    const el = findClickableBySignature(step.signature);
    if (!el) return { ok: false, reason: 'Nie znaleziono przycisku', label: step.label };
    try {
      el.classList.add('ftf-click-highlight');
      // Krótka pauza wizualna - lekarz widzi co kliknięto
      await sleep(200);
      el.click();
      return { ok: true, label: step.label };
    } catch (e) {
      return { ok: false, reason: e.message, label: step.label };
    }
  }

  function findFieldBySignature(sig) {
    if (sig.id) {
      const el = document.getElementById(sig.id);
      if (el && matchesShape(el, sig)) return el;
    }
    if (sig.name) {
      const els = document.querySelectorAll(`${sig.tag}[name="${CSS.escape(sig.name)}"]`);
      const candidates = Array.from(els).filter(el => matchesShape(el, sig));
      if (candidates.length === 1) return candidates[0];
    }
    if (sig.stablePath) {
      try {
        const el = document.querySelector(sig.stablePath);
        if (el && matchesShape(el, sig)) return el;
      } catch {}
    }
    if (sig.labelText) {
      const labels = Array.from(document.querySelectorAll('label'));
      for (const label of labels) {
        if (label.textContent.trim() === sig.labelText) {
          const forId = label.getAttribute('for');
          if (forId) {
            const target = document.getElementById(forId);
            if (target && matchesShape(target, sig)) return target;
          }
          const inner = label.querySelector(sig.tag);
          if (inner && matchesShape(inner, sig)) return inner;
        }
      }
    }
    if (sig.placeholder) {
      const el = document.querySelector(`${sig.tag}[placeholder="${CSS.escape(sig.placeholder)}"]`);
      if (el && matchesShape(el, sig)) return el;
    }
    if (sig.ariaLabel) {
      const el = document.querySelector(`${sig.tag}[aria-label="${CSS.escape(sig.ariaLabel)}"]`);
      if (el && matchesShape(el, sig)) return el;
    }
    if (typeof sig.formIndex === 'number') {
      const form = document.querySelector('form') || document.body;
      const fields = Array.from(form.querySelectorAll('input:not([type="hidden"]), textarea, select'));
      const candidate = fields[sig.formIndex];
      if (candidate && matchesShape(candidate, sig)) return candidate;
    }
    return null;
  }

  function findClickableBySignature(sig) {
    if (sig.id) {
      const el = document.getElementById(sig.id);
      if (el) return el;
    }
    if (sig.stablePath) {
      try {
        const el = document.querySelector(sig.stablePath);
        if (el) return el;
      } catch {}
    }
    if (sig.visibleText) {
      // Szukaj elementu klikalnego z dokładnie tym tekstem
      const all = document.querySelectorAll('button, a, input[type="submit"], input[type="button"], [role="button"]');
      for (const el of all) {
        const txt = (el.textContent || el.value || '').trim();
        if (txt === sig.visibleText) return el;
      }
      // Spróbuj częściowego dopasowania
      for (const el of all) {
        const txt = (el.textContent || el.value || '').trim();
        if (txt.includes(sig.visibleText) || sig.visibleText.includes(txt)) return el;
      }
    }
    if (sig.ariaLabel) {
      const el = document.querySelector(`[aria-label="${CSS.escape(sig.ariaLabel)}"]`);
      if (el) return el;
    }
    return null;
  }

  function matchesShape(el, sig) {
    if (el.tagName.toLowerCase() !== sig.tag) return false;
    if (sig.type && el.type && el.type !== sig.type) return false;
    return true;
  }

  function setFieldValue(el, value) {
    const tag = el.tagName.toLowerCase();
    if (tag === 'select') {
      el.value = value;
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return;
    }
    if (tag === 'textarea') {
      const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
      setter.call(el, value);
    } else if (tag === 'input') {
      if (el.type === 'checkbox' || el.type === 'radio') {
        el.checked = value === true || value === 'true' || value === '1' || value === 'on';
      } else {
        const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
        setter.call(el, value);
      }
    }
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function clearPlaybackHighlights() {
    document.querySelectorAll('.ftf-filled-highlight, .ftf-click-highlight').forEach(el => {
      el.classList.remove('ftf-filled-highlight', 'ftf-click-highlight');
    });
  }

  // ============ WAIT FOR STABLE DOM ============
  // Po `click` musimy poczekać aż strona się "ustabilizuje". Sygnały:
  //  - readyState === 'complete'
  //  - brak mutacji DOM przez ~300ms
  // Działa zarówno dla A (full reload — content reborn), B (SPA), C (toggle).

  function waitForStableDom(timeoutMs) {
    return new Promise((resolve) => {
      const start = Date.now();
      const STABLE_PERIOD_MS = 300;
      let lastMutation = Date.now();
      let observer = null;
      let intervalCheck = null;
      let resolved = false;

      const cleanup = () => {
        if (observer) observer.disconnect();
        if (intervalCheck) clearInterval(intervalCheck);
      };

      const finish = (result) => {
        if (resolved) return;
        resolved = true;
        cleanup();
        resolve(result);
      };

      observer = new MutationObserver(() => {
        lastMutation = Date.now();
      });
      observer.observe(document.body, {
        childList: true, subtree: true, attributes: true, characterData: true
      });

      intervalCheck = setInterval(() => {
        const now = Date.now();
        if (document.readyState === 'complete' && (now - lastMutation) > STABLE_PERIOD_MS) {
          finish({ ok: true, durationMs: now - start });
          return;
        }
        if (now - start > timeoutMs) {
          finish({ ok: false, reason: 'timeout', durationMs: now - start });
        }
      }, 100);
    });
  }

  // ============ SESSION RESUME / SPA NAV ============
  // Po przeładowaniu (opcja A), background powiadamia content script że jesteśmy
  // w trakcie sesji. Wskrzesza tryb na podstawie session.kind.

  function handleSessionResume(session) {
    if (session.kind === 'recording' && session.activeMode === 'fields') {
      // Wznów tryb nagrywania pól na nowej stronie
      startRecordingFields();
      // Side panel sam pokaże baner "kontynuujesz nagrywanie"
    }
    // Dla 'playback' nie robimy nic - sterowanie wraca do sidepanela,
    // który decyduje co robić dalej (kontynuować od kolejnego kroku).
  }

  function handleSpaNavigation(url) {
    // Powiadomienie informacyjne — podobnie jak resume, ale bez wskrzeszania
    // bo content script żyje. Mogłoby być potrzebne w przyszłości.
  }

  // ============ UI HELPERS ============

  let statusBanner = null;
  let bannerOriginal = '';

  function showStatusBanner(text) {
    if (!statusBanner) {
      statusBanner = document.createElement('div');
      statusBanner.id = 'ftf-status-banner';
      document.documentElement.appendChild(statusBanner);
    }
    statusBanner.textContent = text;
    bannerOriginal = text;
  }

  function hideStatusBanner() {
    if (statusBanner) {
      statusBanner.remove();
      statusBanner = null;
    }
  }

  let warningTimeout = null;
  function flashWarning(text) {
    if (!statusBanner) showStatusBanner(text);
    statusBanner.textContent = '⚠️ ' + text;
    statusBanner.classList.add('ftf-banner-warning');
    if (warningTimeout) clearTimeout(warningTimeout);
    warningTimeout = setTimeout(() => {
      if (statusBanner) {
        statusBanner.textContent = bannerOriginal;
        statusBanner.classList.remove('ftf-banner-warning');
      }
    }, 2000);
  }

  function sleep(ms) {
    return new Promise(r => setTimeout(r, ms));
  }
})();
