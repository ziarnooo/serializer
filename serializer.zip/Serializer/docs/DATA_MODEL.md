# Model danych

Dokument opisuje format **szablonów** zapisywanych w `chrome.storage.local`, oraz format **sygnatur pól** używanych do identyfikacji elementów na stronie.

## Template (szablon)

Top-level obiekt zapisywany w `chrome.storage.local` w kluczu `templates` (tablica).

```typescript
type Template = {
  id: string;              // 'tpl_<timestamp>_<random>' — unikalny ID
  name: string;            // Czytelna nazwa, np. "Wizyta kontrolna - dorosły"
  matchUrl: string;        // Wzorzec URL pierwszej strony, wildcard *
  createdAt: string;       // ISO 8601
  steps: Step[];           // Sekwencja kroków, wykonywana w kolejności
};
```

**Przykład:**

```json
{
  "id": "tpl_1717000000000_a1b2c3",
  "name": "Wizyta kontrolna - dorosły",
  "matchUrl": "file:///home/dominik/form-template-extension/test-form-multi/page1.html*",
  "createdAt": "2026-05-04T12:00:00.000Z",
  "steps": [ /* ... */ ]
}
```

### Pola

- **`id`** — generowany przez sidepanel.js przy `saveTemplate()`. Format: `tpl_<Date.now()>_<random6>`. Nigdy nie zmienia się po utworzeniu.
- **`name`** — wyświetlane w UI. Może być duplikowane między szablonami (nie sprawdzamy unikalności).
- **`matchUrl`** — używany do wykrywania, czy bieżąca strona pasuje do szablonu. Obsługa `*` jako wildcard (regex pod spodem). Patrz funkcja `urlMatches()` w `background.js` i `sidepanel.js`. Domyślnie ustawiany na URL pierwszej strony nagrania.
- **`createdAt`** — informacyjnie. Nie używane do sortowania (na razie).
- **`steps`** — sekwencja, wykonywana **w kolejności tablicy**. Pojedynczy krok to `Step`.

## Step (krok)

Discriminated union — `type` decyduje o reszcie schematu.

```typescript
type Step = FillStep | ClickStep;
```

### `FillStep`

Wpisz wartość do pola formularza.

```typescript
type FillStep = {
  type: 'fill';
  pageUrl: string;          // Z której strony krok został nagrany (informacyjnie)
  signature: FieldSignature;
  label: string;            // Czytelna nazwa kroku w UI, np. "Tętno"
  value: string;            // Wartość do wpisania (zawsze string, nawet dla number inputów)
};
```

**Przykład:**

```json
{
  "type": "fill",
  "pageUrl": "file:///.../page2.html",
  "signature": {
    "tag": "input",
    "type": "text",
    "id": "vital-pulse",
    "name": "pulse",
    "placeholder": "np. 72",
    "ariaLabel": null,
    "labelText": "Tętno [/min]",
    "formIndex": 0,
    "stablePath": "form#page2-form > fieldset:nth-of-type(1) > div:nth-of-type(1) > div:nth-of-type(1) > #vital-pulse"
  },
  "label": "Tętno",
  "value": "72"
}
```

**Uwagi:**
- `value` jest zawsze stringiem. Nawet dla `<input type="number">` zapisujemy "72", nie 72.
- Dla `<select>` w `value` jest **value option**, nie tekst (żeby działało nawet jak teksty się przetłumaczą).
- Dla `<input type="checkbox" / "radio">` `value` to `"true"`, `"false"`, `"1"`, lub `"on"` (patrz `setFieldValue` w content.js).

### `ClickStep`

Kliknij element (zwykle przycisk nawigacyjny "Dalej").

```typescript
type ClickStep = {
  type: 'click';
  pageUrl: string;
  signature: ClickableSignature;
  label: string;            // np. "Przejdź: Dalej →"
  waitForNavigation: boolean; // Czy po kliknięciu wtyczka czeka na waitForStableDom
};
```

**Przykład:**

```json
{
  "type": "click",
  "pageUrl": "file:///.../page1.html",
  "signature": {
    "tag": "button",
    "type": "submit",
    "id": "btn-next",
    "name": null,
    "ariaLabel": null,
    "visibleText": "Dalej →",
    "href": null,
    "stablePath": "form#page1-form > div:nth-of-type(1) > #btn-next"
  },
  "label": "Przejdź: Dalej →",
  "waitForNavigation": true
}
```

**Uwagi:**
- `waitForNavigation: true` (domyślnie) — wtyczka po kliku wywołuje `PLAYBACK_WAIT_STABLE` i czeka aż DOM się ustabilizuje (timeout 5s).
- `waitForNavigation: false` — od razu kontynuuje. Sensowne dla klików, które nie zmieniają widoku (np. otwierają tooltip, accept cookies).

## FieldSignature

Multi-warstwowa identyfikacja pola formularza. Każde z pól może być `null` jeśli nie da się go zbudować — wtedy strategia matching pomija to kryterium.

```typescript
type FieldSignature = {
  tag: 'input' | 'textarea' | 'select';
  type: string | null;        // dla input: 'text', 'email', 'number', etc.
  id: string | null;
  name: string | null;
  placeholder: string | null;
  ariaLabel: string | null;
  labelText: string | null;   // Tekst <label> powiązanego z polem
  formIndex: number | null;   // Pozycja wśród pól w najbliższym <form>
  stablePath: string;         // CSS-like ścieżka, bez auto-generowanych klas
};
```

Strategię użycia tych pól przy odtwarzaniu opisuje `FIELD_MATCHING.md`.

## ClickableSignature

Analogicznie dla przycisków/linków.

```typescript
type ClickableSignature = {
  tag: 'button' | 'a' | 'input';
  type: string | null;        // dla input: 'submit', 'button'
  id: string | null;
  name: string | null;
  ariaLabel: string | null;
  visibleText: string;        // ⭐ Najmocniejszy sygnał dla nawigacji
  href: string | null;        // tylko dla <a>
  stablePath: string;
};
```

**Dlaczego `visibleText` jest tu tak ważny:** lekarz nagrał szablon dwa miesiące temu, EDM dostał update i przepisał klasy CSS, ale przycisk dalej ma tekst "Dalej →". Match po tekście działa, gdy strukturalne sygnały zawodzą.

## Storage layout (kompletny)

```typescript
// chrome.storage.local
{
  templates: Template[]
}

// chrome.storage.session
{
  session_recording: RecordingSession | undefined
  session_playback: PlaybackSession | undefined
}

type RecordingSession = {
  tabId: number;
  kind: 'recording';
  activeMode: 'fields' | 'nav' | null;  // który tryb aktywny w content scripcie
  startedAt: string;
  firstPageUrl: string;
  currentPageUrl: string;
  steps: Step[];
};

type PlaybackSession = {
  tabId: number;
  kind: 'playback';
  templateId: string;
  template: Template;       // pełna kopia, niezależna od templates[]
  stepIndex: number;        // następny krok do wykonania
  paused: boolean;
  awaitingNavConfirm: boolean;
  log: PlaybackLogItem[];
};

type PlaybackLogItem = {
  kind: 'fill' | 'nav';
  ok: boolean;
  label: string;
  value?: string;
  reason?: string;          // jeśli !ok
};
```

## Migracje schematu

**Obecnie brak**. Jeśli zmienisz schemat, zrób:

1. Dorzuć pole `schemaVersion: number` do `Template` (zacznij od 2; wszystkie istniejące szablony bez tego pola = wersja 1).
2. W `sidepanel.js` przy odczycie z `chrome.storage.local` sprawdź wersję, w razie potrzeby dokonaj migracji w pamięci (i ewentualnie zapisz z powrotem).
3. Wzór: separate function `migrateTemplate(t: any): Template`.

## Czego nie ma w danych (świadomie)

- **Brak danych pacjenta.** Szablon ma wartości typu "72", "120", "dobry" — to są wartości typowe/domyślne, nie dane konkretnego pacjenta.
- **Brak ID użytkownika / tracking ID.** Wtyczka nie wie kim jesteś.
- **Brak timestampów wykonania.** Nie logujemy "kiedy szablon był użyty" (mógłby być przydatny ale to telemetria).
- **Brak wersji wtyczki w szablonie.** Jeśli okaże się potrzebne dla migracji — dorzuć przy save.

## Walidacja przy save

Aktualnie minimalna:
- `name` musi być niepusty
- `steps` musi mieć przynajmniej jeden `fill`

**Brakuje:**
- Walidacji `matchUrl` jako poprawnego wzorca (nie testujemy regex compilation)
- Walidacji że signatures są kompletne (nie ma null we wszystkich polach jednocześnie)
- Limitów rozmiaru (chrome.storage.local ma 10MB total — dla szablonów mało prawdopodobne)

Dorzuć jeśli zaczną się problemy.
