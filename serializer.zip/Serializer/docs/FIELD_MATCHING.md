# Strategia identyfikacji pól (field matching)

Dokument opisuje, **jak wtyczka znajduje pole formularza** podczas odtwarzania szablonu, gdy strona EDM mogła się zmienić od momentu nagrania.

## Problem

Lekarz nagrał szablon w poniedziałek. We wtorek deweloper EDM zrobił deploy: zmienił klasy CSS, dorzucił dwa nowe pola, przesunął kolejność w formularzu. We środę lekarz odpala wtyczkę — i ma działać.

**Naïwne podejście** (selektor `body > div.container > form > input:nth-child(3)`) zawodzi na każdej drobnej zmianie. Potrzebujemy odporności.

## Rozwiązanie: 6-warstwowa sygnatura

Przy nagrywaniu pola zapisujemy **wszystkie** dostępne sygnały identyfikujące. Przy odtwarzaniu próbujemy ich kolejno, od najmocniejszego do najsłabszego.

```typescript
type FieldSignature = {
  tag: 'input' | 'textarea' | 'select';
  type: string | null;
  id: string | null;
  name: string | null;
  placeholder: string | null;
  ariaLabel: string | null;
  labelText: string | null;
  formIndex: number | null;
  stablePath: string;
};
```

## Strategia matchingu (kolejność prób)

Funkcja `findFieldBySignature()` w `content.js`. Próbuje warstw od najmocniejszej:

### 1. `id` (najmocniejsze)

```js
if (sig.id) {
  const el = document.getElementById(sig.id);
  if (el && matchesShape(el, sig)) return el;
}
```

`id` z założenia jest unikalny w DOM. Jeśli pasuje — biorę. Funkcja `matchesShape` sprawdza, czy `tag` i `type` się zgadzają (żeby nie wziąć przypadkiem przycisku zamiast inputa, jeśli ktoś przerzucił `id`).

**Kiedy zawodzi:** ID auto-generowane (np. `id="mui-2847"` w Material UI), regenerowane przy każdym renderze. Wykrywam to przy buildzie sygnatury — patrz `buildStablePath`, pomija ID z 4+ cyframi z rzędu.

### 2. `name` (mocne)

```js
if (sig.name) {
  const els = document.querySelectorAll(`${sig.tag}[name="${CSS.escape(sig.name)}"]`);
  const candidates = Array.from(els).filter(el => matchesShape(el, sig));
  if (candidates.length === 1) return candidates[0];
}
```

`name` jest często stabilny — to atrybut HTML form, używany przy submit. Tylko jeśli **dokładnie jeden** element pasuje, wracam wynik (inaczej ryzyko ambiguity).

**Kiedy zawodzi:** Same `name` w wielu polach (np. radio buttons), albo nowoczesne JS frameworki w ogóle nie używają `name`.

### 3. `stablePath` (CSS path bez auto-klas)

```js
if (sig.stablePath) {
  try {
    const el = document.querySelector(sig.stablePath);
    if (el && matchesShape(el, sig)) return el;
  } catch {}
}
```

Path budowany przez `buildStablePath()`, np.:
```
form[name="page2-form"] > fieldset:nth-of-type(1) > div:nth-of-type(1) > #vital-pulse
```

Reguły konstrukcji (kod w `content.js:buildStablePath`):
- Idź od elementu w górę, max 6 poziomów.
- Jeśli napotkasz **stabilne `id`** (bez 4+ cyfr) — użyj `#id` i kończ.
- W każdym kroku użyj `tagname[name="..."]` jeśli element ma name.
- Dorzuć `:nth-of-type(N)` jeśli rodzic ma rodzeństwo tego samego typu.
- **Pomiń klasy CSS** — to są efemerydy frameworków.

**Kiedy zawodzi:** strona przebudowała hierarchię (np. owinęła pole w nowy `<div>`). Ale to jest dość rzadkie, bo struktura HTML formularzy jest stosunkowo stabilna.

### 4. `labelText` (semantyczne — tekst label)

```js
if (sig.labelText) {
  const labels = Array.from(document.querySelectorAll('label'));
  for (const label of labels) {
    if (label.textContent.trim() === sig.labelText) {
      const forId = label.getAttribute('for');
      if (forId) {
        const target = document.getElementById(forId);
        if (target && matchesShape(target, sig)) return target;
      }
      const inner = label.querySelector(sig.tag);
      if (inner && matchesShape(inner, sig)) return inner;
    }
  }
}
```

Match po tekście label-a — semantyczny, odporny na restrukturyzację HTML. "Tętno [/min]" zostaje "Tętno [/min]" niezależnie od klas CSS.

**Kiedy zawodzi:**
- Label-a po prostu nie ma (pole bez `<label>`, np. tylko placeholder).
- Tekst label-a został zmieniony (np. "Tętno" → "Pulsacja").
- Tłumaczenie strony (PL → EN) — wszystkie label-y się zmieniają.

### 5. `placeholder` / `aria-label` (fallback)

```js
if (sig.placeholder) {
  const el = document.querySelector(`${sig.tag}[placeholder="${CSS.escape(sig.placeholder)}"]`);
  if (el && matchesShape(el, sig)) return el;
}
if (sig.ariaLabel) {
  const el = document.querySelector(`${sig.tag}[aria-label="${CSS.escape(sig.ariaLabel)}"]`);
  if (el && matchesShape(el, sig)) return el;
}
```

Słabsze niż label, bo placeholder często bywa ozdobny ("np. 72") i może się zmienić przy redesignie. Ale lepsze niż nic.

### 6. `formIndex` (ostatnia deska ratunku)

```js
if (typeof sig.formIndex === 'number') {
  const form = document.querySelector('form') || document.body;
  const fields = Array.from(form.querySelectorAll('input:not([type="hidden"]), textarea, select'));
  const candidate = fields[sig.formIndex];
  if (candidate && matchesShape(candidate, sig)) return candidate;
}
```

"To było 3. pole formularza." Słabe — jeśli ktoś dorzucił nowe pole na początku, indeks się przesunął. Ale w połączeniu z `matchesShape` (sprawdzającym tag/type) zmniejsza ryzyko fałszywego match-u.

### Jeśli nic nie pasuje

Zwracam `null`. Sidepanel wpisuje do logu `{ ok: false, reason: 'Nie znaleziono pola' }` i kontynuuje (nie przerywa całego playbacku — ile się da, to się wypełni).

## Matching klikalnych (`findClickableBySignature`)

Dla przycisków nawigacyjnych ("Dalej") strategia jest prostsza, ale **`visibleText` ma priorytet**:

1. `id` → 2. `stablePath` → 3. **`visibleText` exact** → 4. **`visibleText` partial** → 5. `ariaLabel`

Dlaczego tekst tak ważny? Bo intuicja użytkownika to "ten przycisk z napisem Dalej". Klasy CSS się zmieniają, struktura DOM się zmienia, ale developerzy rzadko zmieniają tekst kluczowych przycisków akcji.

## Co to jest `matchesShape`

```js
function matchesShape(el, sig) {
  if (el.tagName.toLowerCase() !== sig.tag) return false;
  if (sig.type && el.type && el.type !== sig.type) return false;
  return true;
}
```

Minimalna sanity check — zapobiega podstawieniu `<button>` zamiast `<input>` jeśli ktoś przeniósł `id` (rzadko, ale możliwe).

## Buildowanie sygnatury (`buildFieldSignature`)

Wywoływane po kliknięciu pola w trybie recording. Próbuje wyciągnąć **wszystkie** sygnały:

```js
function buildFieldSignature(el) {
  return {
    tag: el.tagName.toLowerCase(),
    type: el.type || null,
    id: el.id || null,
    name: el.getAttribute('name') || null,
    placeholder: el.getAttribute('placeholder') || null,
    ariaLabel: el.getAttribute('aria-label') || null,
    labelText: findLabelText(el),
    formIndex: getFormFieldIndex(el),
    stablePath: buildStablePath(el)
  };
}
```

Funkcja `findLabelText` szuka label-a w 3 miejscach:
1. `<label for="id">` z atrybutem `for` wskazującym na element.
2. Najbliższy ancestor `<label>` (jeśli pole jest opakowane w label).
3. `aria-labelledby` → element z tym ID → jego textContent.

## Debugowanie

Gdy match zawodzi:

### 1. Otwórz DevTools strony testowej
Console.log jest **mało**, ale możesz dodać tymczasowe logi w `findFieldBySignature` do debugowania konkretnego przypadku:

```js
console.log('FTF: trying id', sig.id, '→', el);
console.log('FTF: trying name', sig.name, '→', els);
// ...
```

### 2. Sprawdź sygnaturę w storage

W DevTools sidepanela (PPM na panelu → Inspect):

```js
chrome.storage.local.get('templates').then(d => console.log(d.templates[0].steps))
```

Zobaczysz wszystkie zapisane sygnatury — sprawdź, czy któraś z warstw teoretycznie powinna pasować.

### 3. Porównaj DOM

W DevTools strony EDM:
```js
// Spróbuj każdej warstwy ręcznie
document.getElementById('vital-pulse')                          // warstwa 1
document.querySelectorAll('input[name="pulse"]')                 // warstwa 2
document.querySelector('form#page2-form > fieldset > ...')       // warstwa 3 — wklej stablePath
```

### 4. Możliwe przyczyny porażki

| Symptom | Prawdopodobna przyczyna | Rozwiązanie |
|---------|-------------------------|-------------|
| Wszystkie pola na stronie 2 nie znalezione | Wszystkie warstwy zawodzą | Sprawdź czy strona w ogóle się załadowała przed PLAYBACK_FILL_STEP. Może `waitForStableDom` zwrócił false. |
| Niektóre pola znalezione, niektóre nie | Konkretne pola mają różne struktury | Zbierz sygnatury problematycznych pól, porównaj z DOM-em. Może auto-generowany ID. |
| Pole znalezione, ale wartość nie wpisana | `setFieldValue` nie wywołało eventów | React/Vue mogą wymagać dispatch konkretnego eventa. Patrz sekcja "Frameworki" niżej. |
| Pole znalezione, ale zła wartość (np. inny pacjent) | Auto-fill przeglądarki nadpisał | Wtyczka dispatchuje `input` i `change` — powinno być OK. Sprawdź czy form ma `autocomplete="off"`. |

## Frameworki — uwagi

### React

React monitoruje zmiany value przez wewnętrzny tracker. Ustawienie `el.value = "x"` bezpośrednio bywa ignorowane. Stąd:

```js
const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
setter.call(el, value);
el.dispatchEvent(new Event('input', { bubbles: true }));
```

Native setter omija tracker, dispatch `input` mówi React-owi że value się zmieniło. To działa dla większości przypadków.

### Vue / Angular

Działa analogicznie — `input` event triggeruje binding. Mamy to w `setFieldValue`.

### Custom inputy (np. Material UI date picker)

Mogą być **całkiem niemożliwe** do wypełnienia bez specjalnego kodu. Date pickery zazwyczaj nasłuchują na własne eventy, mają hidden input z value w innym formacie, etc.

**Plan na przyszłość:** dla pól, które się notorycznie nie chcą wypełniać, dorzucić możliwość zapisania **alternatywnej strategii** w sygnaturze (np. "kliknij to → kliknij datę X w kalendarzu"). To większa zmiana, na razie zostawiamy.

### Web Components / Shadow DOM

Wtyczka **nie wchodzi** do shadow DOM. Pola w shadow root są niewidoczne dla `document.querySelector`. To jest świadome ograniczenie — większość EDM-ów nie używa shadow DOM, a wsparcie wymagałoby przeszukiwania rekurencyjnego z dużymi kosztami performance.

## Rozważone i odrzucone alternatywy

### XPath
Bardziej elastyczny niż CSS, ale to ten sam typ informacji co `stablePath`. Nie dodaje nowej warstwy odporności.

### Coordinate-based matching
"Pole było 200px od lewej i 350 od góry." Złe — break-uje się na każdym responsive resize.

### Visual matching (porównanie pixelmap)
Zbyt drogie obliczeniowo, niepewne, ślepe na zmiany koloru/fontu. Nie warto.

### LLM-based field matching
"Daj LLM-owi DOM i sygnaturę, niech zdecyduje." Odrzucone — zwiększa złożoność, niedeterministyczne, wymaga API call (sieć!), albo ogromnego lokalnego modelu. Patrz `ROADMAP.md`.

## Future work

- **Confidence score per match** — zamiast binary "znalazł / nie znalazł", scoring "znalazł z pewnością X%". Niskie scoring → ostrzeżenie w UI.
- **Multi-element resolution UI** — gdy strategia znajduje wielu kandydatów (np. 3 pola z tym samym name), pokazać user-owi listę i pozwolić wybrać.
- **Self-healing signatures** — przy successful match po niskiej warstwie (np. 5 zamiast 1), zaktualizować zapisaną sygnaturę o nowe wartości wyższych warstw. "Adaptacyjna" sygnatura.
