# Roadmap

Co dalej, w kolejności priorytetu. Świadome decyzje co budować — i co świadomie odrzucamy.

## P0 — Niedobre żeby zostawić bez tego

Funkcje, których brak boli przy codziennym użyciu i powinno być następnym krokiem.

### Edycja istniejącego szablonu

**Problem:** dziś jak chcę dodać pole do istniejącego szablonu, muszę go usunąć i nagrać od nowa.

**Rozwiązanie:** w widoku "Twoje szablony" przy każdym dodać przycisk `✎ Edytuj`:
- Otwiera widok edytora z listą wszystkich kroków.
- Możliwości:
  - Zmiana wartości fill-stepa (bez ponownego nagrywania pola).
  - Zmiana nazwy kroku.
  - Usunięcie kroku.
  - **"Dograj kolejne pola"** — wraca do trybu recording-fields, dorzuca do steps[] na końcu.
  - Reorder kroków (drag & drop) — niski priorytet.

**Trudność:** niska. Schema zostaje, dorzucamy widok i akcje.

### Eksport / import JSON

**Problem:** lekarz chce podzielić się szablonem z kolegą.

**Rozwiązanie:** w widoku szablonu przyciski:
- `↓ Eksportuj` — pobiera plik `tpl_<nazwa>.json` z całym Template-em.
- `↑ Importuj` na widoku home — wybiera plik, parsuje, dorzuca do templates[]. Walidacja schemy.

**Trudność:** niska. `chrome.downloads` API + `<input type="file">` w sidepanelu.

### Walidacja wartości — ostrzeżenia o nietypowych

**Problem:** lekarz wpisuje w szablon wartość 320 (bo myślał że to ciśnienie skurczowe), zapisuje jako "Tętno". Przy odtwarzaniu jest za późno na zauważenie.

**Rozwiązanie:** opcjonalna walidacja per-pole:
- Range: `min`, `max`.
- Pattern: regex (np. PESEL).
- Predefiniowane "presety" dla pól medycznych: `pulse: 30..200`, `bp_systolic: 70..250`, `temp: 32..42`, etc.

UI: pod "Wartość do wpisania" mały przycisk `⚙` → rozwija opcje walidacji.

**Trudność:** średnia. Walidacja przy save, runtime warning przy odtwarzaniu.

## P1 — Naprawdę przydatne

### Wiele wariantów wartości w jednym szablonie

**Problem:** "wizyta kontrolna kobieta" i "wizyta kontrolna mężczyzna" różnią się tylko jedną wartością ("płeć"). Dziś trzeba dwa szablony.

**Rozwiązanie:** w fill-stepie zamiast pojedynczej `value`, lista `variants: [{ name, value }]` + UI przy odtwarzaniu pyta "który wariant?".

**Trudność:** średnia. Zmiana modelu danych + UI dla dropdownu wariantów.

### Per-tab session keys

**Problem:** tylko jedna sesja recording/playback naraz w całym Chrome.

**Rozwiązanie:** klucz sesji `session_recording_${tabId}`, `session_playback_${tabId}`.

**Trudność:** niska. Refaktor SESSION_KEYS w 3 miejscach.

### Skróty klawiszowe

**Problem:** otwieranie panelu i klikanie "Wypełnij" co wizyta — wkurzające.

**Rozwiązanie:** `chrome.commands` w manifest:
- `Ctrl+Shift+F` (Win) / `Cmd+Shift+F` (Mac) — zastosuj pierwszy pasujący szablon.
- `Ctrl+Shift+R` — rozpocznij nagrywanie.

**Trudność:** niska. Dorzucenie do manifest + listener w background.

### Lepsza obsługa SPA

**Problem:** dla niektórych SPA (Angular Material) DOM się zmienia przez kilka sekund po `pushState`. `waitForStableDom` może odpalić za wcześnie i pole nie istnieje.

**Rozwiązanie:** dla SPA dorzucić **predicat-based waiting** — czekaj nie tylko na stabilność, ale na pojawienie się **konkretnego pola** z następnego stepa.

**Trudność:** średnia. Wymaga zmiany flow — sidepanel "wie" jaki jest następny step, przekazuje sygnaturę do `waitForStableDom`.

### Custom select / dropdown

**Problem:** nowoczesne EDM często nie używają `<select>`, tylko custom JS dropdowny.

**Rozwiązanie:** rozszerzony recording — gdy user nagrywa "wartość" custom dropdownu, wtyczka zapisuje sekwencję: klik → klik na option z tekstem X. Replay jako mini-flow.

**Trudność:** wysoka. Wymaga rozumienia "to jest dropdown" — nie zawsze oczywiste z DOM.

## P2 — Nice to have

### Statystyki użycia (lokalnie!)

Ile razy szablon był użyty, kiedy ostatnio. Czysto lokalnie, w storage.local. **Bez** sieci.

### Tagi / kategorie szablonów

"Wizyta kontrolna", "Pierwsza wizyta", "Konsultacja" — żeby łatwiej szukać w długiej liście.

### Ciemny motyw

CSS variables są gotowe, wystarczy media query `prefers-color-scheme: dark` + zestaw kolorów.

### Pomoc kontekstowa

Tooltip-y / help cards w kluczowych momentach. Np. "Gdy nagrywasz przejście dalej, wtyczka..."

### Eksport całej biblioteki szablonów (backup)

Jeden zip / JSON ze wszystkimi szablonami. Dla migracji między urządzeniami.

## P3 — Może kiedyś

### Sync między urządzeniami

`chrome.storage.sync` (limit 100 KB total, ale Templates są małe).

**Uwaga:** sync idzie przez konto Google. Dla danych medycznych — przemyśleć compliance. Może zostać feature opt-in z wyraźnym disclaimerem.

### Szablony grupowe (organizacyjne)

Admin szpitala definiuje "standardowe szablony", lekarze widzą je jako read-only. Wymaga back-endu — ale może bardzo prosty: shared folder z plikami JSON, wtyczka go indeksuje.

**Uwaga:** wtedy wprowadzamy sieć. Decyzja architektoniczna do przedyskutowania.

### Macros / multi-template chaining

"Po wypełnieniu szablonu A, automatycznie odpal szablon B." Useful gdy wizyta to kilka połączonych formularzy.

### Webhook / integration triggers

"Po wypełnieniu szablonu, otwórz w nowej karcie URL X." Może być przydatne dla workflow-ów.

**Uwaga:** sieć. Patrz wyżej.

## ❌ Co świadomie odrzucone

### LLM do field matchingu / generowania szablonów

**Argumenty za:** "AI może rozpoznać że pole 'Temp' to temperatura nawet bez label-a."

**Powody odrzucenia:**
1. **Niedeterministyczne.** Lekarz musi mieć pewność co się stanie. AI matcher zachowa się różnie przy każdym uruchomieniu.
2. **Sieć.** Local LLM = 1GB+ model, nieakceptowalne dla wtyczki. Cloud LLM = wysłanie danych medycznych do trzeciej strony, **niedopuszczalne**.
3. **Solving non-problem.** Lekarz manualnie klika pole przy nagrywaniu. Nasza 6-warstwowa sygnatura już jest bardzo odporna. Nie potrzeba AI żeby "rozpoznać pole".
4. **Wzrost złożoności.** Audytowalność wtyczki spada — ktoś nie może już łatwo zweryfikować że nie ma wycieku.

**Decyzja:** nie. Patrz CLAUDE.md.

### Auto-klikanie "Zapisz" na końcu

**Argumenty za:** "Skoro już wypełniliśmy 14 pól, dlaczego nie kliknąć ostatniego przycisku?"

**Powody odrzucenia:**
1. **Bezpieczeństwo medyczne.** Zapis wizyty to świadoma akcja prawna lekarza. Wtyczka pomaga, nie podejmuje finalnych decyzji.
2. **Edge case-y.** Co jeśli pacjent w trakcie wymieni informację? Lekarz musi mieć ostatnią szansę na przejrzenie i korektę.
3. **Audyt.** Jeśli ktoś sprawdzi historię, wszystkie zapisy mają być w logach jako "kliknięte przez lekarza X o godz. Y", nie "auto przez wtyczkę".

**Decyzja:** nigdy. Patrz CLAUDE.md.

### Tracking / telemetria

**Argumenty za:** "Wiedzielibyśmy które funkcje są używane, gdzie są bugi."

**Powody odrzucenia:**
1. **Sieć.** Wtyczka jest 100% offline.
2. **RODO.** Dane medyczne, nawet metadane (kiedy lekarz wypełniał formularz pacjenta), są wrażliwe.
3. **Trust.** Lekarze potrzebują pewności że narzędzie nic nie wysyła.

**Decyzja:** nie. Feedback przez kanały rozmowne (Slack zespołu, GitHub issues).

### Crash reporting / Sentry

Tym samym argumentem. Sentry = sieć. Nie.

### Auto-update bez zgody (Chrome Web Store auto-update)

Standardowo Chrome aktualizuje wtyczki w tle. Dla Twojego docelowego use case (szpital, krytyczne narzędzie) **chcesz kontroli** nad tym kiedy update wchodzi.

**Decyzja:** dystrybucja przez **enterprise policy** (force install z URL który Ty kontrolujesz), nie przez Chrome Web Store. Update wchodzi gdy Ty zdecydujesz.

### Wsparcie dla iframe

**Argumenty za:** "Niektóre EDM-y trzymają formularze w iframe."

**Powody odrzucenia:**
1. **Złożoność.** Cross-frame messaging, hosty, CSP — duża praca.
2. **Niski need.** Twoje docelowe EDM-y? Sprawdź czy w ogóle używają iframe.

**Decyzja:** odłożone do P3. Włącz `all_frames: true` jeśli okaże się potrzebne.

### Wsparcie dla Shadow DOM

Podobnie. Shadow DOM to relatywnie rzadki wzorzec w business apps.

## Jak priorytetyzować dalej

Sugestia: zbierz feedback od **realnego lekarza** używającego wtyczki przez 2 tygodnie. Trzymaj listę "to mi się podoba" / "to mnie wkurza" / "to bym dorzucił". Ranking P0–P3 przerób na podstawie tych danych — to będzie znacznie lepsze niż lista wymyślona z głowy.

Funkcje, których nikt nie zażądał, nie buduj. Funkcje, których 5 osób zażądało, buduj.
