# Rozwój i debugowanie

Dokument opisuje, jak **załadować wtyczkę**, jak ją **modyfikować** i jak **debugować** każdy z trzech komponentów (background / content / sidepanel).

## Pierwsze załadowanie

1. Otwórz Chrome (lub Edge / Brave / Opera — wszystkie chromium).
2. Wejdź na `chrome://extensions`.
3. W prawym górnym rogu włącz **"Tryb dewelopera"**.
4. Kliknij **"Załaduj rozpakowane"** (Load unpacked).
5. Wskaż folder z plikiem `manifest.json` (czyli root tego repo).
6. Wtyczka pojawi się na liście. Sprawdź czy nie ma błędów (czerwony "Errors" link na karcie).

## Po zmianie kodu

| Co zmieniłeś? | Co zrobić? |
|---------------|------------|
| `manifest.json` | Pełne przeładowanie wtyczki (kółko na karcie wtyczki w `chrome://extensions`). |
| `background.js` | Pełne przeładowanie. Service worker ma własny lifecycle. |
| `content.js` / `content.css` | Przeładowanie wtyczki + **odświeżenie wszystkich stron** gdzie content script był wstrzyknięty (Cmd/Ctrl+R). |
| `sidepanel.{html,css,js}` | Zamknij side panel (X w panelu lub klik ikony) i otwórz ponownie. |
| `icons/` | Pełne przeładowanie wtyczki. Ikona w pasku przeglądarki czasem cache-uje — restart Chrome ostatecznie. |

**Skrót:** zwykle wystarczy "Reload" wtyczki + reload strony testowej.

## Trzy oddzielne DevTools

To jedna z najmniej oczywistych rzeczy w dev wtyczek MV3 — **każdy komponent ma własną instancję DevTools**.

### Service Worker (background.js)

```
chrome://extensions
  → karta "Form Template Filler"
  → "Inspect views: service worker"
```

Klikasz, otwiera się DevTools dla service worker-a. Tam:
- `console.log` z `background.js`
- Można odpalić ręcznie kod: `chrome.storage.local.get('templates').then(console.log)`
- Sprawdzić czy listenery webNavigation się odpalają — dorzuć `console.log` w `onCompleted`.

**Ważne:** service worker **zasypia** po ~30s bez aktywności. Jeśli DevTools zniknie — to OK, worker po prostu uśpiony. Wykonanie eventu (np. nawigacja) go wybudza.

### Content Script (content.js)

```
DevTools zwykłej strony (F12 / Cmd+Opt+I)
  → Console
  → Top context: "...your-page.html"
```

Logi z content.js trafiają tu. Możesz też:
- W konsoli wpisać `window.__formTemplateFillerLoaded` — powinno być `true` jeśli content script się załadował.
- Wywołać funkcje z content.js? **Nie bezpośrednio** — content script ma izolowany scope. Trzeba przez `chrome.runtime.sendMessage` z DevTools (nie testowane).

### Sidepanel

```
PPM (prawy klik) na samym side panelu
  → "Inspect"
```

Otwiera się osobne okno DevTools dla sidepanela. Tam:
- Logi z sidepanel.js
- Możesz wywoływać funkcje globalnie (window-scope: `state.recordingSession`, `state.matchingTemplates`, etc.).
- Storage — `chrome.storage.local.get(null).then(console.log)` pokaże wszystko.

## Hot reload? Brak.

Niestety, wtyczki Chrome nie wspierają hot module replacement out-of-the-box. Musisz manualnie reload-ować po każdej zmianie.

**Jeśli chcesz to przyspieszyć:** skrypt który wykrywa zmiany w plikach i programatycznie woła `chrome.runtime.reload()` — możliwe, ale dodaje complexity. Na razie pomijamy.

## Lokalna inspekcja storage

```js
// W DevTools sidepanela:

// Wszystkie szablony
chrome.storage.local.get('templates').then(d => console.table(d.templates));

// Aktywna sesja
chrome.storage.session.get(null).then(console.log);

// Wymaż wszystko (uważaj!)
chrome.storage.local.clear();
chrome.storage.session.clear();

// Wymaż konkretny szablon (po idx)
chrome.storage.local.get('templates').then(d => {
  d.templates.splice(0, 1);
  chrome.storage.local.set(d);
});
```

## Najczęstsze problemy

### "Wtyczka nie reaguje na klik w pole"

Symptom: nagrywanie aktywne, klikam pole, nic się nie dzieje (sidepanel nie pokazuje editora).

Diagnostyka:
1. DevTools strony → Console — czy są błędy z `content.js`?
2. Czy `window.__formTemplateFillerLoaded === true`?
3. Czy strona jest na liście dozwolonych? (`<all_urls>` powinien wystarczać, ale `chrome://` strony są wykluczone z założenia).
4. Czy klik trafił w pole? Przesuń mysz — czy widzisz niebieską obwódkę przy hover? Jeśli nie — listener `mousemove` nie został podłączony, sprawdź `enterRecordingMode`.

### "Po nagraniu strony 2 sidepanel nie reaguje na nową stronę"

Symptom: nagrywam stronę 1, klikam "Dalej", strona 2 załadowana, ale sidepanel ma starą URL i tryb recording-fields nie jest aktywny.

Diagnostyka:
1. Service Worker DevTools — czy `webNavigation.onCompleted` się odpala?
2. Czy session_recording jest zapisana? `chrome.storage.session.get('session_recording')` w sidepanel DevTools.
3. Czy `tabId` w session match-uje aktywną kartę?

### "Po reload sidepanela playback startuje od nowa"

Symptom: w trakcie playback zamykam panel, otwieram, wszystko zaczyna się od kroku 0.

Możliwe przyczyny:
1. `restoreFromSession` nie wczytał `session_playback` poprawnie. Dodaj `console.log(state.playbackSession)` po wczytaniu.
2. `stepIndex` w sesji jest 0 — może `savePlaybackSession` nie został wywołany po inkrementacji.

### "Service worker pokazuje 'Inactive' i nie reaguje"

Service worker zasnął. To normalne. Każde wywołanie eventu (nawigacja, wiadomość, alarm) go wybudzi. Jeśli faktycznie nie reaguje na nawigację — to bug, sprawdź filtry w `webNavigation`.

### "Manifest validation error przy ładowaniu"

Komunikat w `chrome://extensions`:
```
Manifest file is missing or unreadable
```
albo
```
Permission 'X' is unknown or URL pattern is malformed
```

→ błąd składni w `manifest.json` lub nieobsługiwany permission. Sprawdź syntax JSON-em (`python -m json.tool < manifest.json`).

## Testowanie zmian

### Smoke test (5 min)

1. Załaduj wtyczkę.
2. Otwórz `test-form-multi/page1.html` (lokalnie — `file://...`).
3. Otwórz Side Panel (klik ikony wtyczki).
4. Nagraj 3-stronicowy szablon: po 4-6 pól na stronie, 2 przejścia.
5. Zapisz, daj URL `file:///*page*.html`.
6. Wróć na stronę 1 (odśwież F5).
7. Side Panel pokazuje pasujący szablon → kliknij "Wypełnij formularz".
8. Sprawdź: czy wypełnia stronę 1, czy pyta o "Dalej", czy po kliknięciu wypełnia stronę 2, etc.
9. Po zakończeniu sprawdź czy wszystkie 14+ pól mają żółte tło.

Jeśli to wszystko działa — core jest OK. Edge cases zostaw na osobne testy.

### Test odporności sygnatury

1. Nagraj szablon.
2. Otwórz `test-form-multi/page2.html`, edytuj plik (np. zmień klasy CSS, dorzuć dodatkowy div, zmień kolejność label).
3. Odśwież.
4. Sprawdź czy odtwarzanie nadal działa.

Jeśli pole jest "uodpornione" przez którąś z 6 warstw — powinno przetrwać.

### Test pauzy-i-potwierdzenia

1. Odpal playback.
2. Gdy pojawi się "Kliknąć Dalej?" — kliknij **Wstrzymaj** zamiast "Tak".
3. Ręcznie zmień wartość jakiegoś pola na stronie.
4. Kliknij **Wznów**.
5. Sprawdź czy playback kontynuuje od następnego kroku (nie nadpisuje twojej zmiany).

## Linting i formatowanie

**Brak.** Repo jest świadomie minimalistyczne. Jeśli chcesz dodać:
- ESLint: `eslint-config-standard` jest dobrą bazą.
- Prettier: ustaw `printWidth: 100`, `singleQuote: true`.

Pliki są na tyle krótkie, że nie ma sensu odpalać CI/CD.

## Build i pakowanie

### Dev (load unpacked)

To, co używasz teraz. Plik bezpośrednio z folderu.

### Produkcja (.zip dla Chrome Web Store)

```bash
cd form-template-extension
zip -r ../form-template-filler-0.2.0.zip . -x "docs/*" "test-form*" "*.md" ".git/*"
```

Zip uploadujesz na Chrome Web Store Developer Dashboard. Nie aktualne dla Twojego use case (wewnętrzne narzędzie), ale gdyby kiedyś.

### Signed CRX

Chrome Web Store podpisuje to za Ciebie przy publikacji. Self-hosted CRX-y są **deprecated** w nowych wersjach Chrome — nie polecam.

### Enterprise distribution

Jeśli chcesz rozprowadzić wtyczkę w organizacji bez Chrome Web Store:
1. Zip → unpacked extension.
2. Konfiguruj `ExtensionInstallForcelist` w policy GPO / MDM.
3. Hostuj `.crx` na intranet.

To jest setup dla Twojego docelowego use case medycznego — zamknięta sieć szpitala, polityki domeny.

## Code review checklist (przed merge)

- [ ] Brak `console.log` poza świadomymi diagnostykami.
- [ ] Brak `fetch` / `XMLHttpRequest` / sieć.
- [ ] Brak nowych permission w `manifest.json` bez uzasadnienia.
- [ ] Komentarze polskie tam gdzie wcześniej, angielskie nazwy zmiennych.
- [ ] Wszystkie `chrome.runtime.sendMessage` w `try`/`.catch` lub z `lastError` check.
- [ ] Smoke test prze-execute-d (4 pola, 1 przejście, 1 strona — minimum minimum).
- [ ] Czy zmieniony schemat danych? Jeśli tak — bumpuj `schemaVersion` (gdy go w końcu dorzucisz, patrz DATA_MODEL.md).
- [ ] Update `CLAUDE.md` jeśli zmieniłeś coś w decyzjach projektowych.
