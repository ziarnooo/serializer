# Architektura

Dokument opisuje **komponenty** wtyczki, **przepływ danych**, i **protokół wiadomości** między komponentami.

## Diagram komponentów

```
┌─────────────────────────────────────────────────────────────┐
│                      Chrome Extension                        │
│                                                              │
│  ┌──────────────┐       ┌──────────────────┐                │
│  │ background.js│◄─────►│  sidepanel.{html,│                │
│  │ (Service     │       │   css,js}        │                │
│  │  Worker)     │       │  (Side Panel UI) │                │
│  └──────┬───────┘       └────────┬─────────┘                │
│         │                        │                           │
│         │ chrome.runtime.sendMessage                         │
│         │                        │                           │
│  ┌──────▼────────────────────────▼─────────┐                │
│  │         chrome.storage                   │                │
│  │  ┌───────────────┐  ┌─────────────────┐ │                │
│  │  │ .local        │  │ .session        │ │                │
│  │  │ - templates[] │  │ - recording     │ │                │
│  │  │               │  │ - playback      │ │                │
│  │  └───────────────┘  └─────────────────┘ │                │
│  └──────────────────────────────────────────┘                │
│                                                              │
└──────────────────────────┬───────────────────────────────────┘
                           │
                           │ chrome.tabs.sendMessage
                           │
            ┌──────────────▼─────────────────┐
            │   Web Page (EDM, dowolna URL)  │
            │                                │
            │  ┌──────────────────────────┐ │
            │  │ content.js (wstrzyknięty)│ │
            │  │ + content.css            │ │
            │  └──────────┬───────────────┘ │
            │             │                  │
            │             │ DOM manipulation │
            │             ▼                  │
            │  ┌──────────────────────────┐ │
            │  │ Strona DOM               │ │
            │  │ (formularz, przyciski)   │ │
            │  └──────────────────────────┘ │
            └────────────────────────────────┘
```

## Komponenty — odpowiedzialności

### `background.js` (Service Worker)

- Otwiera Side Panel na klik w ikonę (`chrome.sidePanel.setPanelBehavior`).
- Aktualizuje **badge** na ikonie wtyczki gdy bieżąca karta pasuje do jakiegoś szablonu.
- Nasłuchuje **webNavigation** (`onCompleted`, `onHistoryStateUpdated`) — to klucz do multi-page:
  - Po przeładowaniu strony content script umiera. Background wykrywa nową nawigację.
  - Sprawdza czy jest aktywna sesja recording/playback dla tej karty.
  - Jeśli tak, powiadamia nowo-zrodzony content script (`SESSION_RESUME`) i sidepanel (`NAVIGATION_OCCURRED`).
- Forwardingu wiadomości — minimum, większość komunikacji idzie bezpośrednio sidepanel↔content przez `chrome.tabs.sendMessage`.

**Service worker zasypia.** Nie trzymaj nic w jego pamięci — wszystko musi być w `chrome.storage`. Worker odpala się przy każdym evencie i może umrzeć zaraz potem.

### `content.js` (Content Script)

- Wstrzykiwany na każdej stronie (match `<all_urls>`, `run_at: document_idle`).
- Trzyma **stan trybu**: `idle` / `recording-fields` / `recording-nav`. Stan jest lokalny dla konkretnej instancji content scriptu (umiera z reloadem strony).
- Obsługuje 3 mechaniki:
  1. **Recording**: hover (rysowanie obwódek), click (interception, nie pozwala formularzowi się submitować), wysyła `FIELD_SELECTED` / `NAV_ELEMENT_SELECTED` do sidepanelu.
  2. **Playback**: wykonuje pojedyncze kroki na żądanie sidepanelu (`PLAYBACK_FILL_STEP`, `PLAYBACK_CLICK_STEP`, `PLAYBACK_WAIT_STABLE`).
  3. **Wskrzeszanie**: po reload `SESSION_RESUME` z background mówi mu w jakim trybie ma być.
- Buduje **signatures** (sygnatury pól / klikalnych) i znajduje elementy po sygnaturach przy odtwarzaniu — szczegóły w `FIELD_MATCHING.md`.

### `sidepanel.{html,css,js}` (UI)

- Główny interfejs użytkownika.
- **Sterownik playback** — sidepanel decyduje kiedy wykonać `fill`, kiedy `click`, kiedy poczekać.
  - Powód: tylko sidepanel widzi wszystkie kroki naraz. Content script jest "głupi" — wykonuje pojedyncze polecenia.
- **Stan recording** trzymany w `chrome.storage.session` — sidepanel jest jedynym pisarzem.
- **Wskrzeszenie po reload sidepanela** (np. zamknięcie i ponowne otwarcie panela): `restoreFromSession()` przy DOMContentLoaded sprawdza czy są aktywne sesje i odbudowuje UI.

## Storage — co gdzie

### `chrome.storage.local`

**Przeżywa wszystko** — restart Chrome, odinstalowanie kart. Tu są **persystowane szablony**.

```
{
  templates: [
    {
      id: 'tpl_...',
      name: '...',
      matchUrl: '...',
      createdAt: '...',
      steps: [...]
    },
    ...
  ]
}
```

### `chrome.storage.session`

**Żyje tylko podczas sesji okna Chrome.** Kasowane przy zamknięciu okna. Tu są **stany operacji**.

```
{
  session_recording: {
    tabId, kind: 'recording', activeMode, startedAt,
    firstPageUrl, currentPageUrl, steps: [...]
  },
  session_playback: {
    tabId, kind: 'playback', templateId, template,
    stepIndex, paused, awaitingNavConfirm, log: [...]
  }
}
```

Jest tylko **jedna aktywna sesja każdego rodzaju** w tym samym czasie. Recording i playback są wzajemnie wykluczające w UI (nie da się ich uruchomić jednocześnie z UI), ale technicznie mogłyby istnieć równolegle dla różnych kart.

## Protokół wiadomości

### Sidepanel → Content (przez `chrome.tabs.sendMessage`)

| Typ | Payload | Odpowiedź |
|-----|---------|-----------|
| `START_RECORDING_FIELDS` | — | `{ ok: true }` |
| `START_RECORDING_NAV_CLICK` | — | `{ ok: true }` |
| `STOP_RECORDING` | — | `{ ok: true }` |
| `MARK_FIELD_RECORDED` | `{ signature }` | `{ ok: true }` |
| `MARK_NAV_RECORDED` | `{ signature }` | `{ ok: true }` |
| `CLEAR_RECORDED_MARKS` | — | `{ ok: true }` |
| `PLAYBACK_FILL_STEP` | `{ step }` | `{ ok: bool, label, value? \| reason? }` |
| `PLAYBACK_CLICK_STEP` | `{ step }` | `{ ok: bool, label, reason? }` (async) |
| `PLAYBACK_WAIT_STABLE` | `{ timeoutMs }` | `{ ok: bool, durationMs, reason? }` (async) |
| `CLEAR_PLAYBACK_HIGHLIGHTS` | — | `{ ok: true }` |
| `GET_PAGE_INFO` | — | `{ url, title, readyState }` |

### Content → Sidepanel (przez `chrome.runtime.sendMessage`)

| Typ | Payload |
|-----|---------|
| `FIELD_SELECTED` | `{ signature, meta }` (po kliknięciu pola w trybie recording-fields) |
| `NAV_ELEMENT_SELECTED` | `{ signature, meta }` (po kliknięciu przycisku w trybie recording-nav) |
| `RECORDING_CANCELLED` | `{ wasMode }` (po naciśnięciu ESC) |

### Background → Content

| Typ | Payload | Kiedy |
|-----|---------|-------|
| `SESSION_RESUME` | `{ session }` | Po `webNavigation.onCompleted`, jeśli aktywna sesja dla tej karty |
| `SPA_NAVIGATION` | `{ url }` | Po `webNavigation.onHistoryStateUpdated` (SPA pushState) |

### Background → Sidepanel

| Typ | Payload |
|-----|---------|
| `NAVIGATION_OCCURRED` | `{ tabId, url, session, spa? }` |

### Sidepanel → Background

| Typ | Payload | Cel |
|-----|---------|-----|
| `GET_ACTIVE_TAB` | — | Odczyt aktywnej karty (alternatywa dla `chrome.tabs.query`) |
| `REFRESH_BADGE` | — | Wymuś przeliczenie badge (np. po dodaniu/usunięciu szablonu) |

## Cykl życia

### Recording (multi-page, opcja A — pełne reload)

```
1. User klika "Nagraj nowy szablon" w sidepanel
   → sidepanel tworzy session_recording
   → sidepanel wysyła START_RECORDING_FIELDS do content
   → content rejestruje listenery hover/click

2. User klika pole na stronie
   → content przechwytuje click, builduje signature
   → content → FIELD_SELECTED → sidepanel
   → sidepanel pokazuje editor, user wpisuje wartość
   → user klika "Dodaj pole"
   → sidepanel zapisuje step do session_recording.steps
   → sidepanel → MARK_FIELD_RECORDED → content (zielona obwódka)

3. User klika "Nagraj przejście dalej"
   → sidepanel → START_RECORDING_NAV_CLICK → content
   → user klika przycisk "Dalej"
   → content → NAV_ELEMENT_SELECTED → sidepanel
   → sidepanel pokazuje nav editor, user zatwierdza
   → sidepanel zapisuje step click do session_recording.steps
   → sidepanel → PLAYBACK_CLICK_STEP → content (faktyczny klik)
   → strona się przeładowuje
   → CONTENT SCRIPT UMIERA

4. Nowa strona załadowana
   → background webNavigation.onCompleted
   → background sprawdza session_recording (tabId match)
   → background czeka 200ms, wysyła SESSION_RESUME do nowego content
   → background wysyła NAVIGATION_OCCURRED do sidepanela
   → content wskrzesza tryb recording-fields
   → sidepanel aktualizuje UI (currentPageUrl, baner "nowa strona")

5. User kontynuuje na nowej stronie (powtórka kroku 2)
   ... aż klika "Zapisz szablon"

6. Sidepanel → flush session_recording → templates[] w storage.local
```

### Playback (multi-page, opcja A)

```
1. User klika "Wypełnij formularz" przy pasującym szablonie
   → sidepanel tworzy session_playback (stepIndex=0)
   → sidepanel wywołuje continuePlayback()

2. continuePlayback iteruje:
   - Jeśli step.type === 'fill':
     → PLAYBACK_FILL_STEP → content → wypełnia, podświetla na żółto
     → log dopisywany, stepIndex++
     → setTimeout 150ms → continuePlayback
   - Jeśli step.type === 'click':
     → awaitingNavConfirm = true
     → UI pokazuje "Kliknąć Dalej?" (pauza-i-potwierdź)

3. User klika "Tak, kliknij"
   → confirmNavAndContinue
   → PLAYBACK_CLICK_STEP → content → klika
   → strona się przeładowuje
   → SIDEPANEL nadal żyje (boczny panel)
   → ale content script umiera z poprzedniej strony
   → background wykrywa nawigację, wskrzesza session
   → sidepanel jest świadomy NAVIGATION_OCCURRED

4. Po reload — jeśli sidepanel był otwarty:
   → restoreFromSession czyta session_playback
   → continuePlayback od stepIndex (gdzie zostawił)
   → kontynuuje fill na nowej stronie

5. Po ostatnim kroku → finalizePlayback
```

## Granice trustu

- **Strona EDM** to untrusted environment. Content script nie ufa DOM-owi (np. label-y mogą być fałszywe, ale jak signature pasuje — fillujemy).
- **Wtyczka NIE wykonuje JS-a ze strony.** Tylko czyta DOM i ustawia wartości pól.
- **Wtyczka NIE czyta cookies, localStorage, sessionStorage strony.** Operuje tylko na DOM-ie.
- **Brak komunikacji z internetem.** CSP `connect-src 'self'`, brak `fetch`/`XMLHttpRequest`/`WebSocket`.

## Dlaczego MV3 a nie MV2

- MV2 jest deprecated od 2024. Nowe wtyczki muszą być MV3.
- Service worker zamiast persistent background page — mniejsze zużycie pamięci.
- Side Panel API to MV3 feature (potrzebne dla naszego UI).

## Co przemyśleć przy refaktorze

- **Jeden moduł `field-matcher`** wydzielony z content.js — łatwiej testować, podmieniać strategię.
- **Type checking** — TypeScript lub JSDoc + tsc check. Obecnie JSDoc-style komentarze są minimalne.
- **State machine library** dla playback — XState? Na razie wystarcza ręczne zarządzanie stanem, ale rośnie.
