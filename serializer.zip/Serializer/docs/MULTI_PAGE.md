# Obsługa formularzy wieloetapowych

Dokument opisuje, **jak wtyczka radzi sobie z formularzami rozłożonymi na wiele stron** — zarówno przy nagrywaniu, jak i odtwarzaniu.

## Trzy typy nawigacji

W formularzach wieloetapowych są trzy fundamentalnie różne mechaniki:

### Opcja A — Pełne przeładowanie URL

Klasyczne formularze server-side. Klikasz "Dalej", strona się przeładowuje (`<form action="/page2" method="post">` lub `<form method="get">`).

```
URL: /wizyta/dane-pacjenta  →  /wizyta/pomiary
DOM: kompletnie nowy
```

**Wyzwanie dla wtyczki:** content script **umiera**. Cała pamięć JS znika. Trzeba mieć stan w `chrome.storage.session` i wskrzesić go po reload.

### Opcja B — SPA, history API zmienia URL

Single Page Application (React Router, Vue Router, Angular Router). Klik "Dalej" → `history.pushState` → URL się zmienia, ale strona NIE jest przeładowywana. JS framework przepisuje DOM.

```
URL: /wizyta/dane-pacjenta  →  /wizyta/pomiary  (push state)
DOM: przepisany przez JS
Content script: ŻYJE
```

**Wyzwanie dla wtyczki:** content script żyje, ale stary DOM zniknął. Trzeba rozpoznać że nawigacja się stała (i poczekać na nowy DOM).

### Opcja C — Wizard bez nawigacji

Multi-step w jednym DOM, "Dalej" tylko `display: none` na poprzedniej sekcji i `display: block` na następnej. URL się **nie zmienia**.

```
URL: /wizyta  (bez zmian)
DOM: te same elementy, zmienia się tylko visibility
Content script: ŻYJE
```

**Wyzwanie dla wtyczki:** żadne nawigacyjne sygnały nie się odpalają. Trzeba poczekać na zmianę widoczności pól.

## Uniwersalny mechanizm `waitForStableDom`

Zamiast trzech różnych implementacji, jeden mechanizm obsługuje wszystkie trzy.

```js
function waitForStableDom(timeoutMs) {
  // 1. MutationObserver na document.body — śledzi DOM zmiany
  // 2. Co 100ms sprawdzaj:
  //    - readyState === 'complete' AND
  //    - od ostatniej mutacji minęło >= 300ms
  // 3. Jeśli tak — DOM jest stabilny, return ok
  // 4. Po timeoutMs — return failure
}
```

Dlaczego to działa dla wszystkich trzech:

- **Opcja A:** po reload nowy content script ładuje się, wywołuje `waitForStableDom`. `readyState` przechodzi z `loading` → `interactive` → `complete`. DOM przestaje się zmieniać. ✓
- **Opcja B:** content script żyje. Po `history.pushState` framework przerysowuje DOM (mutacje przez kilka frame'ów React-a). MutationObserver to widzi. Po ~300ms ciszy → stable. ✓
- **Opcja C:** klik "Dalej" w wizardzie zmienia `display: none → block` na sekcjach. To jedna mutacja, potem cisza. → stable bardzo szybko. ✓

Timeout 5s — jeśli strona ładuje się dłużej (slow API, ciężki JS), wtyczka pauzuje i pokazuje user-owi komunikat: "Strona nie ustabilizowała się — wstrzymano. Kliknij Wznów gdy gotowa."

## Mechanizm wskrzeszania sesji (kluczowy dla opcji A)

To jest najsubtelniejsza część architektury.

### Recording — co przeżywa reload

```
[Strona 1]
  User klika "Nagraj nowy szablon" w sidepanel
  → sidepanel zapisuje session_recording w chrome.storage.session
    {
      tabId: 42,
      kind: 'recording',
      activeMode: 'fields',
      currentPageUrl: 'page1.html',
      steps: []
    }

  User klika 4 pola → sidepanel dopisuje 4 fill-stepy

  User klika "→ Nagraj przejście dalej" w panelu
  → sidepanel ustawia activeMode='nav', wysyła START_RECORDING_NAV_CLICK do content
  → content wchodzi w tryb recording-nav (podświetla klikalne elementy)

  User klika "Dalej" na stronie
  → content.js zapisuje pending_nav_click = { signature, meta, pageUrl, capturedAt }
    w chrome.storage.session
  → content.js wywołuje stopRecording() (tryb → idle)
  → NIE blokuje eventu — form submit/link działa normalnie
  → strona zaczyna się przeładowywać

[Reload — content script umiera]

[Strona 2 załadowana]
  Background: webNavigation.onCompleted (tabId=42, frameId=0)
  Background: sprawdza session_recording — znalezione, tabId match
  Background: setTimeout(200ms) — pozwala content scriptowi się załadować
  Background → content: SESSION_RESUME { session: { activeMode: 'nav', ... } }
  Background → sidepanel: NAVIGATION_OCCURRED { url: 'page2.html', ... }

  Content: handleSessionResume → activeMode='nav' → nic nie robi
    (sterowanie oddane do sidepanela)

  Sidepanel: onNavigationOccurred
    → czyta pending_nav_click z chrome.storage.session
    → dopisuje click-step do session_recording.steps (używając signature z pending_nav_click)
    → usuwa pending_nav_click z session storage
    → ustawia currentPageUrl='page2.html', activeMode='fields'
    → pokazuje nav-editor z prośbą o nazwę kroku ("Przejdź: Dalej →")
    → po 50ms wysyła START_RECORDING_FIELDS do content

  Content: START_RECORDING_FIELDS → tryb recording-fields aktywny
    → user może klikać kolejne pola
```

### Recording — co jeśli sidepanel zostanie zamknięty

Sidepanel można zamknąć (np. przypadkiem). Co wtedy?

- `chrome.storage.session` wciąż żyje.
- Po ponownym otwarciu sidepanela: `restoreFromSession()` przy DOMContentLoaded.
- Sidepanel wczytuje `session_recording`, switchView('recording'), `renderRecordedSteps()` — wraca dokładnie do stanu sprzed zamknięcia.

### Playback — analogicznie

```
[Strona 1]
  Sidepanel zapisuje session_playback
    {
      tabId: 42,
      kind: 'playback',
      stepIndex: 0,
      template: { steps: [fill, fill, click, fill, fill, click, fill] },
      ...
    }

  Sidepanel: continuePlayback iteruje
    → step 0 (fill): PLAYBACK_FILL_STEP → content → ok → stepIndex=1
    → step 1 (fill): ... → stepIndex=2
    → step 2 (click): awaitingNavConfirm = true → UI pokazuje "Kliknąć Dalej?"

  User klika "Tak, kliknij"
  → confirmNavAndContinue
  → PLAYBACK_CLICK_STEP → content → klik → strona reload-uje
  → stepIndex=3, awaitingNavConfirm=false (zapisane przed reloadem)
  → PLAYBACK_WAIT_STABLE → ale content script umiera w trakcie

[Reload]
  Sidepanel: jest osobnym oknem, NIE umiera z reloadem strony
  Sidepanel kontynuuje, ale nowy content script potrzebuje chwili

  Background: webNavigation.onCompleted (sidepanel tego nie potrzebuje, ale OK)

  Sidepanel: PLAYBACK_WAIT_STABLE wraca z timeout (poprzedni content nie żył)
    LUB
  Sidepanel: PLAYBACK_WAIT_STABLE wraca z OK (nowy content już ładny)

  Sidepanel: continuePlayback (od stepIndex=3)
    → step 3 (fill): ... → kontynuuje na stronie 2
```

### Edge case — sidepanel zamknięty PODCZAS playbacku

Jeśli user zamknie sidepanel w trakcie odtwarzania:

- `session_playback` żyje w storage.
- Po otwarciu: `restoreFromSession` znajduje session_playback, switchView('playback'), `renderPlaybackUI`, i po 500ms `continuePlayback`.
- **Ale:** stepIndex może być w stanie nie-spójnym (np. content już wypełnił pole, ale sidepanel umarł zanim odebrał response). Wtedy fill się powtórzy — dla pól tekstowych to bez różnicy (nadpisana ta sama wartość), dla checkboxów może powstać problem (toggle).

**Rozwiązanie obecne:** akceptujemy ryzyko. Większość pól w EDM medycznych to inputy tekstowe, gdzie powtórzenie jest idempotentne.

**Rozwiązanie przyszłe:** trzymać `stepIndex` nie jako "następny do wykonania", a jako "ostatni potwierdzony OK". Po reload zaczynać od ostatniego potwierdzonego + 1.

## SPA navigation (`onHistoryStateUpdated`)

Background nasłuchuje też SPA nav:

```js
chrome.webNavigation.onHistoryStateUpdated.addListener((details) => {
  // Send SPA_NAVIGATION to content (ale content i tak żyje)
  // Send NAVIGATION_OCCURRED to sidepanel z spa: true
});
```

Dla SPA nie trzeba wskrzeszać niczego — content żyje, sidepanel żyje. Sygnał jest **informacyjny** — sidepanel może zaktualizować `currentPageUrl` w UI.

Funkcja `handleSpaNavigation` w content.js obecnie nie robi nic ważnego. Mogłaby:
- Re-aktywować tryb recording-fields (jeśli wcześniej był nav klik).
- Wyczyścić podświetlenia z poprzedniego "widoku".

Na razie pomijamy — `START_RECORDING_FIELDS` po `MARK_NAV_RECORDED` w sidepanel.js wystarcza.

## Nagrywanie multi-page — flow użytkownika

1. **Strona 1.** User klika "Nagraj nowy szablon" → wraca do strony, klika 4 pola, dla każdego wpisuje wartość.
2. **Przejście.** User klika "→ Nagraj przejście dalej" w panelu → wraca do strony → klika "Dalej →" na stronie.
3. Klik wykonuje się **naturalnie** — strona sama się przeładowuje (form submit, link itp.).
4. **Strona 2 załadowana.** Panel pokazuje: "✓ Zarejestrowano przejście — nadaj nazwę krokowi: [Przejdź: Dalej →]". User klika "Zapisz" (lub zmienia label) → krok trafia do szablonu. Tryb recording-fields aktywny.
5. User dorzuca kolejne 6 pól.
6. **Drugie przejście.** "→ Nagraj przejście dalej" → klika "Dalej →" → strona 3.
7. **Strona 3.** Analogicznie — prompt z nazwą przejścia, potem nagrywanie pól.
8. **Koniec.** User klika "Zapisz szablon" → nazwa, match URL, save.

Klucz: **user nie potwierdza przed nawigacją** — klik jest naturalny, strona reaguje jak bez wtyczki. Wtyczka tylko "zapamiętuje" klik przez `pending_nav_click` w session storage i dopisuje step po fakcie.

## Odtwarzanie multi-page — flow użytkownika

1. **Strona 1** załadowana. User otwiera Side Panel — widzi pasujący szablon.
2. Klika "Wypełnij formularz" → 4 pola się wypełniają na strony 1 (żółte tło).
3. Pojawia się karta: **"Kliknąć Dalej?"** z przyciskami "Wstrzymaj" / "Tak, kliknij".
4. User sprawdza wartości, klika "Tak, kliknij".
5. Wtyczka klika Dalej → strona 2 ładuje się.
6. Po stabilizacji DOM-a: 6 pól się wypełnia.
7. Karta "Kliknąć Dalej?" → "Tak, kliknij" → strona 3.
8. 4 ostatnie pola się wypełniają.
9. **KONIEC** — sidepanel pokazuje "✓ Wypełniono wszystkie 14 pól przez 3 strony."
10. **User sam klika "Zapisz wizytę"** w EDM. Wtyczka tego nie robi.

## Co nie jest obsłużone

### Cofanie się (Wstecz)

Jeśli user kliknie "Wstecz" w EDM podczas nagrywania — sesja przeszła na poprzednią stronę. Wtyczka wykryje nawigację i wskrzesi recording-fields, ale **steps zostaną zachowane** (też te z poprzednich stron). User dorzuci pola na "wcześniejszej" stronie, sidepanel dopisze do steps[].

Przy odtwarzaniu — **steps są wykonywane w kolejności tablicy**. Jeśli między step 5 (fill na page 2) a step 6 (fill na page 1) brakuje click-stepa cofającego, playback złamie się.

**Workaround:** nagrywaj liniowo, nie wracaj.

### Wiele kart jednocześnie

Wtyczka trzyma jedno `session_recording` i jedno `session_playback` w `chrome.storage.session`. Jeśli user otworzy drugą kartę i zacznie tam nagrywać, **nadpisze** poprzednią sesję.

**Workaround:** kończ nagrywanie przed otwarciem drugiej karty.

**Future:** klucz sesji per-tab (`session_recording_${tabId}`).

### Forms w iframe

Wtyczka działa tylko w top frame (`all_frames: false` w manifest). Pola w iframe są niewidoczne.

**Future:** ustawić `all_frames: true` i robić cross-frame messaging. Skomplikowane, na razie pomijamy.

### Forms otwierające się w nowych zakładkach

Jeśli klik "Dalej" otwiera nową kartę zamiast nawigować — wtyczka nie podąży. Sesja recording w starej karcie zostanie "zawieszona" na zawsze (do zamknięcia okna).

**Workaround:** target=_self na linkach. Nie ingeruj w wybór kanału.

## Diagnostyka multi-page

Jeśli odtwarzanie się zatrzymuje między stronami:

1. **Sidepanel DevTools** (PPM → Inspect) — sprawdź `chrome.storage.session.get('session_playback')`. Czy `stepIndex` jest tam, gdzie oczekujesz?
2. **Background DevTools** — `chrome://extensions` → karta wtyczki → "Inspect views: service worker". Sprawdź czy `webNavigation.onCompleted` się odpala.
3. **Content script DevTools** — DevTools strony EDM, console, dorzuć `console.log` w `waitForStableDom` żeby zobaczyć timing.
4. **Czy klik faktycznie się odbywa?** Sprawdź żółtą pulsację po `PLAYBACK_CLICK_STEP`. Jeśli jej nie ma → przycisk nie został znaleziony (sprawdź visibleText).
